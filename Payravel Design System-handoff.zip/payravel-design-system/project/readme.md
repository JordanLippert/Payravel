# Payravel Design System

The design system for **Payravel** — a multi-currency payment-management
platform for companies with employees across countries. Employees file payment /
reimbursement requests in their local currency; Payravel captures a live exchange
rate, converts to **EUR**, and routes the request to a finance reviewer for
approval before expiry.

- **Frontend:** Nuxt.js · **Backend:** Laravel 12
- **Brand basis:** Buzzvel (buzzvel.com) — red `#CC0000`, dark `#0f0f0f`/`#1a1a1a`,
  white + transparent-white grays. Dark mode only, flat design.

> **Sources given:** No codebase, Figma, or deck was attached. This system was
> authored from the written Payravel brief (the visual language is derived from
> Buzzvel's stated identity). If a Nuxt repo or Figma file exists, re-attach it
> and the components/UI kit can be reconciled against the real source.

---

## Content fundamentals

- **Language:** Portuguese (pt-BR) throughout the product UI. Currency formatting
  is pt-BR / European (`R$ 1.200,00`, `€ 2.317,44` — dot thousands, comma decimals).
- **Voice:** direct, calm, operational. Second person ("Suas requisições",
  "Acesse seu painel"). Short greetings ("Olá, Marina"). No marketing fluff inside
  the app; the only aspirational copy is the login brand panel
  ("Pagamentos multi-moeda, sem fronteiras.").
- **Casing:** sentence case for headings and buttons ("Nova requisição", "Enviar
  para aprovação"). UPPERCASE only for micro eyebrow labels above tables/metrics,
  with `0.04em` tracking.
- **Status words:** fixed vocabulary — **Pendente · Aprovado · Rejeitado ·
  Expirado**. Always paired with the matching status color.
- **Numbers are first-class:** monetary values and rates render in Geist Mono with
  tabular figures so columns align. Currency code + flag glyph travel together
  (`🇺🇸 USD`).
- **Emoji:** used sparingly and only functionally — flag glyphs for currencies and
  a check (`✓`) in the "ao vivo ✓" live-rate badge. No decorative emoji.

---

## Visual foundations

- **Mode:** dark only. Canvas `#0f0f0f`, surfaces/topbar/cards `#1a1a1a`, menus
  `#1f1f1f`. No light theme.
- **Accent:** a single brand red `#CC0000` (hover `#B30000`, pressed `#990000`).
  Red is reserved for primary actions, the logo mark, active nav, the metric
  accent strip, and the finance-role pill. It is never a background wash.
- **Flat design:** no gradients, no decorative shadows. Depth comes from borders
  and surface steps only. The single exception is a faint drop shadow on floating
  menus/popovers (`--shadow-menu`).
- **Borders:** the signature is a **0.5px** hairline in transparent white —
  `subtle` (7%), `default` (10%), `strong` (15%). Inputs warm their border to a
  soft red (`rgba(204,0,0,0.45)`) on hover/focus.
- **Typography:** Geist (UI) + Geist Mono (amounts/rates). **Weights 400 and 500
  only** — never bold/700. Large amounts use `-0.02em` tracking.
- **Radii:** 6px on controls (buttons, inputs, badges), 8px on cards/panels/menus,
  full (999px) on avatars and pills.
- **Spacing:** 4px base grid; compact, data-dense rhythm (24px card padding, 32px
  page gutters).
- **Color of imagery:** there is no photography — the aesthetic is pure flat UI on
  near-black. The only large color field is the solid-red login panel.
- **Motion:** minimal and functional. 120ms ease on hover/border/background
  transitions; finance approve/reject rows tint then fade out (~900ms). No
  bounces, no infinite loops, no parallax.
- **Hover states:** primary buttons darken; ghost buttons lift to a faint white
  fill + stronger border; table rows lift to a 3% white wash; nav links brighten
  from 50%→70% text.
- **Press states:** buttons darken one more step (no scale transform).
- **Cards:** `#1a1a1a` fill, 8px radius, 0.5px subtle border, **no shadow**. A 2px
  red left strip marks a highlighted KPI.
- **Status system:** pending = amber `#F5A524`, approved = green `#2BBD6E`,
  rejected = red `#F04444`, expired = gray (white 45%). Each badge is a tinted
  fill (12%) + matching 30% border + a leading dot.

---

## Iconography

- **No bundled icon font or SVG set was provided** with the brief. The system
  currently uses a tiny set of **Unicode glyphs** for the few marks it needs:
  `+` (new request), `←` (back), `▾` (select chevron), `✓` / `✕` (approve / reject
  and the live-rate check), `⏱` (expiry warning). These are intentionally minimal
  and match the flat, text-forward aesthetic.
- **Currency flags** use emoji flag glyphs (🇧🇷 🇺🇸 🇪🇺 🇬🇧 🇯🇵) as functional
  indicators in the currency picker and tables.
- The **logo** is the **moeda-câmbio + ciclo** mark: a coin split on the diagonal
  (€ filled half → $ open half) wrapped by a custom **double-arrow conversion
  ring**. Monochrome **vermelho + preto**; the ring can spin (~5s) for “câmbio ao
  vivo” on splash/loading and the topbar hover. It reduces cleanly — the ring
  holds to ~32px, and at ≤20px the favicon drops to just the coin. Authored as the
  `Logo` component (`components/brand/Logo.jsx`); no raster assets. See
  `guidelines/logo-final.html` for construction, the mono set, lockups and the
  animation.
- **If you need a richer icon set:** adopt [Lucide](https://lucide.dev) via CDN —
  its 1.5px stroke, rounded-join style matches this system better than filled
  icons. **(Flagged substitution — confirm before standardizing.)**

---

## Index / manifest

**Root**
- `styles.css` — global entry point (consumers link this); `@import` manifest only.
- `tokens/` — `fonts.css`, `colors.css`, `typography.css`, `spacing.css`, `radius.css`.
- `readme.md` — this file.
- `SKILL.md` — Agent-Skills wrapper for use in Claude Code.

**Components** (`window.PayravelDesignSystem_6c6388.*`)
- `components/brand/` — **Logo** (official mark: split coin + conversion ring)
- `components/forms/` — **Button**, **Input**, **Select**
- `components/data-display/` — **Badge**, **Avatar**, **Card**, **MetricCard**
- `components/navigation/` — **Topbar**, **Pill**, **Stepper**

**UI kits**
- `ui_kits/payravel/` — five **desktop** screens + interactive `index.html`
  (Login · Dashboard · Nova requisição · Detalhe · Painel financeiro).
- `ui_kits/payravel-mobile/` — the same five screens reimagined as a **fintech
  mobile app** (390px): red-hero Login, balance-hero Início, 3-step Nova
  requisição with live FX, Detalhe with timeline, and a Financeiro queue with
  inline approve/reject. Bottom tab bar with an elevated center "+" (Nubank/Wise
  pattern); interactive `index.html` with a reviewer switcher. Mobile bends the
  card radius up to 14–20px for the softer app feel; everything else follows the
  shared tokens. Icons use **Lucide** path data (the system's recommended set).

**Foundation cards** (Design System tab)
- `guidelines/*.card.html` — color, type, spacing, radius, border specimens.
- `guidelines/logo-final.html` — official logo: construction, mono set, lockups, animation.

**Starting points**
- Components: Button, MetricCard, Topbar, Logo.
- Screens: `ui_kits/payravel/start-dashboard.html`, `start-finance.html`.

---

## Notes & substitutions
- **Font:** no brand font was specified — **Geist + Geist Mono** were chosen as a
  clean grotesk pairing and loaded from Google Fonts. Swap if the brand has a
  licensed face.
- **Namespace:** `PayravelDesignSystem_6c6388` (use in `@dsCard` HTML).
