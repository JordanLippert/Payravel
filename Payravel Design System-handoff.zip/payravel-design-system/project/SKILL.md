---
name: payravel-design
description: Use this skill to generate well-branded interfaces and assets for Payravel, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files.

Payravel is a dark-mode, flat, multi-currency payment-management product (red
`#CC0000` accent on `#0f0f0f`/`#1a1a1a`, Geist type, 0.5px hairline borders, weights
400/500 only). The full visual and content rules live in `readme.md`.

- **Tokens:** `styles.css` (links everything in `tokens/`). Link this one file and
  use the CSS custom properties — never hardcode hex values.
- **Components:** `components/<group>/<Name>.jsx` (Button, Input, Select, Badge,
  Avatar, Card, MetricCard, Topbar, Pill, Stepper). Each has a `.d.ts` contract and
  `.prompt.md` usage note.
- **UI kit:** `ui_kits/payravel/` — five recreated screens + interactive `index.html`.

If creating visual artifacts (slides, mocks, throwaway prototypes), copy the assets
and token CSS out and produce static HTML files for the user to view. If working on
production code, copy the tokens and read the rules here to design as an expert in
this brand.

If the user invokes this skill without other guidance, ask what they want to build,
ask a few clarifying questions, then act as an expert Payravel designer who outputs
HTML artifacts _or_ production code, depending on the need.
