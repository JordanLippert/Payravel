**Logo** — the official Payravel mark: a split coin (€ filled → $) wrapped by a double-arrow conversion ring. Use it anywhere the brand appears (topbar, login, favicon, splash).

```jsx
<Logo />                                  {/* horizontal lockup, red on dark */}
<Logo variant="mark" size={26} />          {/* just the mark */}
<Logo variant="stacked" size={48} />       {/* mark above wordmark */}
<Logo color="#fff" knockout="#CC0000"      {/* white-on-red, e.g. login panel */}
      wordmarkColor="#fff" />
<Logo variant="mark" animated />           {/* ring spins — splash / hover */}
```

Monochrome by design (vermelho + preto). `color` drives the coin+ring; `knockout` is the € cut-out. For tiny favicons (≤20px) prefer `variant="mark"` — the ring still reads. Never recolor into gradients or add a shadow.
