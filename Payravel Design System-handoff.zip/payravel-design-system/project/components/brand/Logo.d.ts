import * as React from 'react';

export interface LogoProps {
  /** Composition. @default 'lockup' */
  variant?: 'mark' | 'lockup' | 'stacked';
  /** Mark height in px (wordmark scales from it). @default 28 */
  size?: number;
  /** Coin + ring color. @default brand red */
  color?: string;
  /** €-cutout color on the filled half. @default '#000' */
  knockout?: string;
  /** Wordmark text color. @default --text-primary */
  wordmarkColor?: string;
  /** Spin the conversion ring (câmbio ao vivo). @default false */
  animated?: boolean;
  style?: React.CSSProperties;
}

/**
 * Official Payravel logo — split coin (€→$) + conversion ring.
 * @startingPoint section="Brand" subtitle="Logo: mark, lockup, animated" viewport="700x200"
 */
export function Logo(props: LogoProps): JSX.Element;
