import React from 'react';

/**
 * Payravel Logo — the official "moeda-câmbio + ciclo" mark.
 * A split coin (€ filled → $) wrapped by a custom double-arrow conversion ring.
 * Monochrome (vermelho + preto). Renders as mark-only, horizontal lockup, or stacked.
 * The ring can spin (câmbio ao vivo) via `animated`.
 */
export function Logo({
  variant = 'lockup',          // 'mark' | 'lockup' | 'stacked'
  size = 28,                   // mark height in px
  color = 'var(--red-500)',    // coin + ring color
  knockout = '#000',           // € cut-out color (sits on the filled half)
  wordmarkColor = 'var(--text-primary)',
  animated = false,
  style = {},
  ...rest
}) {
  const rawId = React.useId();
  const uid = rawId.replace(/[:]/g, '');
  const mark = <LogoMark size={size} color={color} knockout={knockout} animated={animated} uid={uid} />;

  if (variant === 'mark') {
    return <span style={{ display: 'inline-flex', ...style }} {...rest}>{mark}</span>;
  }
  const stacked = variant === 'stacked';
  return (
    <span
      style={{
        display: 'inline-flex',
        flexDirection: stacked ? 'column' : 'row',
        alignItems: 'center',
        gap: stacked ? size * 0.2 : size * 0.16,
        ...style,
      }}
      {...rest}
    >
      {mark}
      <span style={{
        fontFamily: 'var(--font-sans)', fontWeight: 'var(--weight-medium)',
        letterSpacing: '-0.03em', color: wordmarkColor,
        fontSize: size * 0.62, lineHeight: 1,
      }}>Payravel</span>
    </span>
  );
}

function LogoMark({ size, color, knockout, animated, uid }) {
  const r = 17, fs = 12;
  const eg = { x: 32 - r * 0.32, y: 32 - r * 0.32 + fs * 0.36 };
  const dg = { x: 32 + r * 0.36, y: 32 + r * 0.36 + fs * 0.36 };
  const sw = 2.3;
  return (
    <svg viewBox="0 0 64 64" width={size} height={size} style={{ display: 'block', overflow: 'visible' }} aria-label="Payravel">
      <defs>
        <clipPath id={`ul-${uid}`}><polygon points="-4,-4 68,-4 -4,68" /></clipPath>
      </defs>
      {/* conversion ring (orbits outside the coin) */}
      <g>
        {animated && (
          <animateTransform attributeName="transform" type="rotate" from="0 32 32" to="360 32 32" dur="5s" repeatCount="indefinite" />
        )}
        <path d="M40.2 9.45 A24 24 0 0 1 40.2 54.55" fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" />
        <path d="M42.6 49.4 L40.2 54.55 L45.3 57" fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" />
        <path d="M23.8 54.55 A24 24 0 0 1 23.8 9.45" fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" />
        <path d="M21.4 14.6 L23.8 9.45 L18.7 7" fill="none" stroke={color} strokeWidth={sw} strokeLinecap="round" strokeLinejoin="round" />
      </g>
      {/* split coin: filled upper-left half (€ knockout), $ in the open half */}
      <circle cx="32" cy="32" r={r} fill={color} clipPath={`url(#ul-${uid})`} />
      <text x={eg.x} y={eg.y} fontFamily="var(--font-sans)" fontSize={fs} fontWeight="500" fill={knockout} textAnchor="middle">€</text>
      <text x={dg.x} y={dg.y} fontFamily="var(--font-sans)" fontSize={fs} fontWeight="500" fill={color} textAnchor="middle">$</text>
    </svg>
  );
}
