**Pill** — topbar user capsule (avatar + name). Pass `role` to flag elevated access; the whole pill turns solid red.

```jsx
<Pill name="Marina Alves" />
<Pill name="Lucas Finance" role="Finance" />
```

The red treatment is reserved for the finance role panel — don't use it for ordinary employees.
