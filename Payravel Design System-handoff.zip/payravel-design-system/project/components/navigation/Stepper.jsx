import React from 'react';

/**
 * Payravel Stepper — vertical progress rail for the new-request flow
 * (Detalhes → Câmbio → Revisão). Past steps red-filled with check, current
 * step ringed red, future steps muted.
 */
export function Stepper({ steps = [], current = 0, style = {} }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 0, ...style }}>
      {steps.map((step, i) => {
        const done = i < current;
        const active = i === current;
        const last = i === steps.length - 1;
        const title = typeof step === 'string' ? step : step.title;
        const desc = typeof step === 'string' ? null : step.desc;
        return (
          <div key={i} style={{ display: 'flex', gap: 12, position: 'relative' }}>
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
              <span style={{
                width: 26, height: 26, borderRadius: 999, flex: 'none',
                display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
                fontFamily: 'var(--font-sans)', fontSize: 12, fontWeight: 'var(--weight-medium)',
                background: done ? 'var(--red-500)' : 'transparent',
                color: done ? '#fff' : active ? 'var(--red-500)' : 'var(--text-muted)',
                border: `0.5px solid ${done ? 'var(--red-500)' : active ? 'var(--red-border)' : 'var(--border-default)'}`,
              }}>{done ? '✓' : i + 1}</span>
              {!last && <span style={{ width: '0.5px', flex: 1, minHeight: 28, background: done ? 'var(--red-border)' : 'var(--border-default)' }} />}
            </div>
            <div style={{ paddingBottom: last ? 0 : 22, paddingTop: 3 }}>
              <div style={{
                fontSize: 14, fontFamily: 'var(--font-sans)',
                fontWeight: active ? 'var(--weight-medium)' : 'var(--weight-regular)',
                color: active || done ? 'var(--text-primary)' : 'var(--text-tertiary)',
              }}>{title}</div>
              {desc && <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2, fontFamily: 'var(--font-sans)' }}>{desc}</div>}
            </div>
          </div>
        );
      })}
    </div>
  );
}
