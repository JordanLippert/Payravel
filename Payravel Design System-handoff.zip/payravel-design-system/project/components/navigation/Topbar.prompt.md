**Topbar** — the global app header. The official `Logo` (moeda-câmbio mark + "Payravel" wordmark; ring spins on hover), nav links, user pill on the right.

```jsx
<Topbar
  user={{ name: 'Marina Alves' }}
  nav={[
    { label: 'Dashboard', active: true },
    { label: 'Requisições' },
    { label: 'Histórico' },
  ]}
/>
```

For the finance panel, pass `user={{ name: 'Lucas', role: 'Finance' }}` so the pill turns red. Composes `Pill` + `Avatar`.
