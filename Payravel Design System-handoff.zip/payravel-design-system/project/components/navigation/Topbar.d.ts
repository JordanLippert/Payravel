import * as React from 'react';

export interface NavItem {
  label: string;
  active?: boolean;
}

export interface TopbarProps {
  /** Nav links. */
  nav?: NavItem[];
  /** Current user. Pass `role` (e.g. "Finance") to flag elevated access. */
  user?: { name: string; role?: string | null };
  onNav?: (item: NavItem) => void;
  style?: React.CSSProperties;
}

/**
 * Global app header — Payravel logo (ring spins on hover), nav links, user pill.
 * @startingPoint section="Navigation" subtitle="App topbar with logo + user pill" viewport="900x56"
 */
export function Topbar(props: TopbarProps): JSX.Element;
