import * as React from 'react';

export interface StepperStep {
  title: string;
  desc?: string;
}

export interface StepperProps {
  /** Steps as strings or { title, desc } objects. */
  steps: Array<string | StepperStep>;
  /** Zero-based index of the active step. @default 0 */
  current?: number;
  style?: React.CSSProperties;
}

/** Vertical progress rail for the new-request flow. */
export function Stepper(props: StepperProps): JSX.Element;
