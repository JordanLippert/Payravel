import React from 'react';
import { Avatar } from '../data-display/Avatar.jsx';

/**
 * Payravel user Pill — avatar + name in a rounded capsule. When `role` is set
 * (e.g. "Finance"), the whole pill turns solid red to flag elevated access.
 */
export function Pill({ name = '', role = null, style = {} }) {
  const isElevated = !!role;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 8,
      padding: '4px 12px 4px 4px', borderRadius: 'var(--radius-full)',
      background: isElevated ? 'var(--red-500)' : 'var(--bg-input)',
      border: `0.5px solid ${isElevated ? 'transparent' : 'var(--border-default)'}`,
      fontFamily: 'var(--font-sans)', cursor: 'default',
      ...style,
    }}>
      <Avatar name={name} size={26} color={isElevated ? 'rgba(0,0,0,0.25)' : 'var(--red-500)'} />
      <span style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.2 }}>
        <span style={{ fontSize: 13, fontWeight: 'var(--weight-medium)', color: isElevated ? '#fff' : 'var(--text-primary)' }}>{name}</span>
        {role && <span style={{ fontSize: 11, color: 'rgba(255,255,255,0.8)' }}>{role}</span>}
      </span>
    </span>
  );
}
