import React from 'react';
import { Pill } from './Pill.jsx';
import { Logo } from '../brand/Logo.jsx';

/**
 * Payravel Topbar — #1a1a1a bar with the moeda-câmbio logo, nav links, and a
 * user Pill at the right. Nav items: { label, active }. The logo ring spins on
 * hover (câmbio ao vivo).
 */
export function Topbar({
  nav = [],
  user = { name: '', role: null },
  onNav = () => {},
  style = {},
}) {
  const [logoHover, setLogoHover] = React.useState(false);
  return (
    <header style={{
      display: 'flex', alignItems: 'center', gap: 32,
      height: 60, padding: '0 24px',
      background: 'var(--bg-surface)',
      borderBottom: '0.5px solid var(--border-subtle)',
      fontFamily: 'var(--font-sans)',
      ...style,
    }}>
      {/* Logo — ring spins on hover */}
      <div
        style={{ display: 'flex', alignItems: 'center', cursor: 'pointer' }}
        onMouseEnter={() => setLogoHover(true)}
        onMouseLeave={() => setLogoHover(false)}
      >
        <Logo size={44} animated={logoHover} />
      </div>

      {/* Nav */}
      <nav style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
        {nav.map((item, i) => (
          <button
            key={i}
            type="button"
            onClick={() => onNav(item)}
            style={{
              background: 'transparent', border: 'none', cursor: 'pointer',
              padding: '6px 12px', borderRadius: 'var(--radius-sm)',
              fontFamily: 'var(--font-sans)', fontSize: 14,
              fontWeight: item.active ? 'var(--weight-medium)' : 'var(--weight-regular)',
              color: item.active ? 'var(--text-primary)' : 'var(--text-tertiary)',
              transition: 'color 120ms ease, background 120ms ease',
            }}
            onMouseEnter={(e) => { if (!item.active) e.currentTarget.style.color = 'var(--text-secondary)'; }}
            onMouseLeave={(e) => { if (!item.active) e.currentTarget.style.color = 'var(--text-tertiary)'; }}
          >{item.label}</button>
        ))}
      </nav>

      <div style={{ marginLeft: 'auto' }}>
        <Pill name={user.name} role={user.role} />
      </div>
    </header>
  );
}
