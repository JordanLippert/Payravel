import * as React from 'react';

export interface PillProps {
  /** User name shown next to the avatar. */
  name: string;
  /** Elevated role label (e.g. "Finance"). When set, the pill turns solid red. */
  role?: string | null;
  style?: React.CSSProperties;
}

/** Topbar user capsule — turns red to flag an elevated role. */
export function Pill(props: PillProps): JSX.Element;
