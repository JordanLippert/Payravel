**Stepper** — vertical progress rail for the new payment-request flow. Past steps fill red with a check, current is ringed red.

```jsx
<Stepper current={1} steps={[
  { title: 'Detalhes', desc: 'Descrição e valor' },
  { title: 'Câmbio', desc: 'Taxa ao vivo' },
  { title: 'Revisão', desc: 'Confirmar e enviar' },
]} />
```

Accepts plain strings or `{ title, desc }`. Drive `current` from form progress.
