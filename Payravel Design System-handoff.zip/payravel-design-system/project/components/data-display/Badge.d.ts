import * as React from 'react';

export interface BadgeProps {
  /** Request state. @default 'neutral' */
  status?: 'pending' | 'approved' | 'rejected' | 'expired' | 'neutral';
  /** Show the leading dot. @default true */
  dot?: boolean;
  /** Override label (defaults to the Portuguese status word). */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}

/** Tinted status pill for the four request states. */
export function Badge(props: BadgeProps): JSX.Element;
