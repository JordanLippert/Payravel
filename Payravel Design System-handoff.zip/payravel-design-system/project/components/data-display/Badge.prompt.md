**Badge** — tinted status pill for the four payment-request states. Defaults its own Portuguese label per status.

```jsx
<Badge status="pending" />        {/* → Pendente (amber) */}
<Badge status="approved" />       {/* → Aprovado (green) */}
<Badge status="rejected" />       {/* → Rejeitado (red)  */}
<Badge status="expired" />        {/* → Expirado (gray)  */}
<Badge status="approved">ao vivo ✓</Badge>  {/* custom label */}
```

Set `dot={false}` to drop the leading dot. Use `status="neutral"` for non-status chips.
