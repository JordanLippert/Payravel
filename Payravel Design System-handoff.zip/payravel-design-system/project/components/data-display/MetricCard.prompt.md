**MetricCard** — dashboard KPI tile: small label, big Geist-Mono value, optional sub line.

```jsx
<MetricCard label="Total enviado" value="R$ 48.200" sub="12 requisições" />
<MetricCard label="Pendente" value="3" tone="pending" accent />
<MetricCard label="Aprovado" value="€ 2.317,44" tone="approved" />
```

`tone` tints the value by status; `accent` adds the red left strip for a highlighted KPI. Values are tabular figures — pre-format the string.
