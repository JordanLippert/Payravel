import * as React from 'react';

export interface AvatarProps {
  /** Full name — initials are derived from the first two words. */
  name?: string;
  /** Diameter in px. @default 32 */
  size?: number;
  /** Background fill. @default brand red */
  color?: string;
  /** Optional image source; overrides initials. */
  src?: string;
  style?: React.CSSProperties;
}

/** Circular initials/image avatar, solid red by default. */
export function Avatar(props: AvatarProps): JSX.Element;
