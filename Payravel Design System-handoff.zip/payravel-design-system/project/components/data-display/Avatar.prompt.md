**Avatar** — circular initials chip, solid brand red. Used in the topbar pill and history timeline.

```jsx
<Avatar name="Marina Alves" />
<Avatar name="Finance Team" size={28} />
```

Derives up to two initials from `name`. Pass `src` for a photo, `size` for diameter, `color` to override the red fill.
