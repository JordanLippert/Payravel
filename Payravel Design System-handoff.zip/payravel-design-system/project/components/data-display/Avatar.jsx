import React from 'react';

/**
 * Payravel Avatar — circular initials chip, solid brand red by default.
 * Used in the topbar user pill and timeline entries.
 */
export function Avatar({ name = '', size = 32, color = 'var(--red-500)', src = null, style = {} }) {
  const initials = name
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join('')
    .toUpperCase();

  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      width: size, height: size, borderRadius: 'var(--radius-full)',
      background: src ? 'transparent' : color, color: '#fff', overflow: 'hidden',
      fontFamily: 'var(--font-sans)', fontWeight: 'var(--weight-medium)',
      fontSize: Math.round(size * 0.4), flex: 'none', lineHeight: 1,
      ...style,
    }}>
      {src ? <img src={src} alt={name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : initials}
    </span>
  );
}
