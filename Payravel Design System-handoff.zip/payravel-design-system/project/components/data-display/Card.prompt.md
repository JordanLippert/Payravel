**Card** — flat surface panel (#1a1a1a, 8px radius, hairline border, no shadow). The base container for tables, forms, and panels.

```jsx
<Card>Conteúdo do painel</Card>
<Card padded={false}><table>…</table></Card>
```

Set `padded={false}` when the child manages its own padding (e.g. a full-bleed table).
