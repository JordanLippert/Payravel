import * as React from 'react';

export interface MetricCardProps {
  /** Small label above the value. */
  label: React.ReactNode;
  /** Big mono value (formatted string, e.g. "€ 2.317,44"). */
  value: React.ReactNode;
  /** Optional sublabel / delta line. */
  sub?: React.ReactNode;
  /** Show the red left accent strip (highlighted KPI). @default false */
  accent?: boolean;
  /** Tint the value by status. @default 'default' */
  tone?: 'default' | 'pending' | 'approved' | 'rejected';
  style?: React.CSSProperties;
}

/**
 * Dashboard KPI tile — label, big mono value, optional sub line.
 * @startingPoint section="Data display" subtitle="KPI metric tiles" viewport="700x160"
 */
export function MetricCard(props: MetricCardProps): JSX.Element;
