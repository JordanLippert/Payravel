import React from 'react';

const STATUS = {
  pending: { fg: 'var(--status-pending-fg)', bg: 'var(--status-pending-bg)', bd: 'var(--status-pending-border)', label: 'Pendente' },
  approved: { fg: 'var(--status-approved-fg)', bg: 'var(--status-approved-bg)', bd: 'var(--status-approved-border)', label: 'Aprovado' },
  rejected: { fg: 'var(--status-rejected-fg)', bg: 'var(--status-rejected-bg)', bd: 'var(--status-rejected-border)', label: 'Rejeitado' },
  expired: { fg: 'var(--status-expired-fg)', bg: 'var(--status-expired-bg)', bd: 'var(--status-expired-border)', label: 'Expirado' },
  neutral: { fg: 'var(--text-secondary)', bg: 'var(--bg-input)', bd: 'var(--border-default)', label: '' },
};

/**
 * Payravel status Badge. Soft tinted fill + matching border + leading dot.
 * Maps the four request states (pendente / aprovado / rejeitado / expirado).
 */
export function Badge({ status = 'neutral', children, dot = true, style = {} }) {
  const s = STATUS[status] || STATUS.neutral;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 6,
      padding: '3px 9px', borderRadius: 'var(--radius-sm)',
      fontSize: 12, fontWeight: 'var(--weight-medium)', lineHeight: 1.4,
      fontFamily: 'var(--font-sans)', whiteSpace: 'nowrap',
      color: s.fg, background: s.bg, border: `0.5px solid ${s.bd}`,
      ...style,
    }}>
      {dot && <span style={{ width: 6, height: 6, borderRadius: 999, background: s.fg, flex: 'none' }} />}
      {children || s.label}
    </span>
  );
}
