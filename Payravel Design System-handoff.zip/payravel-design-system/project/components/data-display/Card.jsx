import React from 'react';

/**
 * Payravel Card — flat surface panel. #1a1a1a fill, 8px radius, hairline border,
 * no shadow. The base container for tables, forms, metric groups, detail panes.
 */
export function Card({ padded = true, children, style = {}, ...rest }) {
  return (
    <div
      style={{
        background: 'var(--surface-card)',
        border: '0.5px solid var(--border-subtle)',
        borderRadius: 'var(--radius-md)',
        padding: padded ? 'var(--pad-card)' : 0,
        ...style,
      }}
      {...rest}
    >
      {children}
    </div>
  );
}
