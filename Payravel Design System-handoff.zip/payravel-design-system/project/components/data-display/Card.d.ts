import * as React from 'react';

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Apply default interior padding. @default true */
  padded?: boolean;
  children?: React.ReactNode;
}

/** Flat #1a1a1a surface panel with hairline border — the base container. */
export function Card(props: CardProps): JSX.Element;
