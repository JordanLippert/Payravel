import React from 'react';

/**
 * Payravel MetricCard — the dashboard KPI tile. Label on top, big mono value,
 * optional sublabel/delta and an accent strip for the "highlighted" metric.
 */
export function MetricCard({
  label,
  value,
  sub = null,
  accent = false,
  tone = 'default', // default | pending | approved | rejected
  style = {},
}) {
  const tones = {
    default: 'var(--text-primary)',
    pending: 'var(--status-pending-fg)',
    approved: 'var(--status-approved-fg)',
    rejected: 'var(--status-rejected-fg)',
  };
  return (
    <div style={{
      position: 'relative',
      background: 'var(--surface-card)',
      border: '0.5px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      padding: '18px 20px',
      display: 'flex', flexDirection: 'column', gap: 10,
      overflow: 'hidden',
      ...style,
    }}>
      {accent && <span style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 2, background: 'var(--red-500)' }} />}
      <span style={{
        fontSize: 12, color: 'var(--text-tertiary)', fontWeight: 'var(--weight-medium)',
        fontFamily: 'var(--font-sans)',
      }}>{label}</span>
      <span style={{
        fontFamily: 'var(--font-mono)', fontWeight: 'var(--weight-medium)',
        fontSize: 28, letterSpacing: '-0.02em', color: tones[tone] || tones.default,
        fontVariantNumeric: 'tabular-nums', lineHeight: 1,
      }}>{value}</span>
      {sub && (
        <span style={{ fontSize: 12, color: 'var(--text-muted)', fontFamily: 'var(--font-sans)' }}>{sub}</span>
      )}
    </div>
  );
}
