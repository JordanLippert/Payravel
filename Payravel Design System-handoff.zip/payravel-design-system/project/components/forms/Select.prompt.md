**Select** — custom dropdown that renders flag glyphs; the currency picker on the payment form.

```jsx
<Select label="Moeda" value={cur} onChange={setCur} options={[
  { value: 'BRL', label: 'Real brasileiro', flag: '🇧🇷', meta: 'BRL' },
  { value: 'USD', label: 'Dólar americano', flag: '🇺🇸', meta: 'USD' },
  { value: 'GBP', label: 'Libra esterlina', flag: '🇬🇧', meta: 'GBP' },
]} />
```

Each option takes `value`, `label`, optional `flag` (emoji) and `meta` (code). Controlled via `value` + `onChange(value)`. Closes on outside click.
