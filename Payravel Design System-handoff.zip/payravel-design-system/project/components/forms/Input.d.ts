import * as React from 'react';

export interface InputProps extends Omit<React.InputHTMLAttributes<HTMLInputElement>, 'prefix'> {
  /** Field label rendered above the control. */
  label?: React.ReactNode;
  /** Helper text rendered below. */
  hint?: React.ReactNode;
  value?: string;
  placeholder?: string;
  /** Read-only fields (e.g. auto-fetched exchange rate, calculated EUR). */
  readOnly?: boolean;
  disabled?: boolean;
  type?: string;
  /** Leading adornment node (icon, currency glyph). */
  prefix?: React.ReactNode;
  /** Trailing adornment node (e.g. a live-rate badge). */
  suffix?: React.ReactNode;
  /** Render value with Geist Mono + tabular figures. @default false */
  mono?: boolean;
}

/** Labelled text input with translucent fill and soft-red focus border. */
export function Input(props: InputProps): JSX.Element;
