import React from 'react';

/**
 * Payravel Select — a styled dropdown. Used for the currency picker, where each
 * option carries a flag glyph + code. Controlled via `value`/`onChange`(value).
 * Lightweight custom popover so we can render flags; not a native <select>.
 */
export function Select({
  label = null,
  value,
  onChange = () => {},
  options = [],
  placeholder = 'Selecionar',
  disabled = false,
  style = {},
}) {
  const [open, setOpen] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const ref = React.useRef(null);

  React.useEffect(() => {
    function onDoc(e) { if (ref.current && !ref.current.contains(e.target)) setOpen(false); }
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);

  const selected = options.find((o) => o.value === value);
  const borderColor = open || hover ? 'var(--red-border)' : 'var(--border-default)';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, ...style }} ref={ref}>
      {label && (
        <span style={{ fontSize: 12, fontWeight: 'var(--weight-medium)', color: 'var(--text-tertiary)', fontFamily: 'var(--font-sans)' }}>{label}</span>
      )}
      <div style={{ position: 'relative' }}>
        <button
          type="button"
          disabled={disabled}
          onClick={() => setOpen((o) => !o)}
          onMouseEnter={() => setHover(true)}
          onMouseLeave={() => setHover(false)}
          style={{
            width: '100%', display: 'flex', alignItems: 'center', gap: 8,
            height: 38, padding: '0 12px',
            background: 'var(--bg-input)', border: `0.5px solid ${borderColor}`,
            borderRadius: 'var(--radius-sm)', cursor: disabled ? 'not-allowed' : 'pointer',
            color: selected ? 'var(--text-primary)' : 'var(--text-muted)',
            fontFamily: 'var(--font-sans)', fontSize: 14,
            transition: 'border-color 120ms ease', opacity: disabled ? 0.4 : 1,
          }}
        >
          {selected ? (
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8 }}>
              {selected.flag && <span style={{ fontSize: 16, lineHeight: 1 }}>{selected.flag}</span>}
              <span>{selected.label}</span>
            </span>
          ) : placeholder}
          <span style={{ marginLeft: 'auto', color: 'var(--text-muted)', transform: open ? 'rotate(180deg)' : 'none', transition: 'transform 120ms ease' }}>▾</span>
        </button>
        {open && (
          <div style={{
            position: 'absolute', top: 'calc(100% + 4px)', left: 0, right: 0, zIndex: 20,
            background: 'var(--bg-elevated)', border: '0.5px solid var(--border-default)',
            borderRadius: 'var(--radius-md)', boxShadow: 'var(--shadow-menu)',
            padding: 4, maxHeight: 240, overflowY: 'auto',
          }}>
            {options.map((o) => {
              const isSel = o.value === value;
              return (
                <div
                  key={o.value}
                  onClick={() => { onChange(o.value); setOpen(false); }}
                  style={{
                    display: 'flex', alignItems: 'center', gap: 8,
                    padding: '8px 10px', borderRadius: 'var(--radius-sm)',
                    cursor: 'pointer', color: 'var(--text-primary)',
                    fontFamily: 'var(--font-sans)', fontSize: 14,
                    background: isSel ? 'var(--bg-input-hover)' : 'transparent',
                  }}
                  onMouseEnter={(e) => { e.currentTarget.style.background = 'var(--bg-input-hover)'; }}
                  onMouseLeave={(e) => { e.currentTarget.style.background = isSel ? 'var(--bg-input-hover)' : 'transparent'; }}
                >
                  {o.flag && <span style={{ fontSize: 16, lineHeight: 1 }}>{o.flag}</span>}
                  <span>{o.label}</span>
                  {o.meta && <span style={{ marginLeft: 'auto', color: 'var(--text-muted)', fontSize: 12, fontFamily: 'var(--font-mono)' }}>{o.meta}</span>}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
