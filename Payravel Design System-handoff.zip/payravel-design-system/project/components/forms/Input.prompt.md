**Input** — labelled text field with the signature translucent fill and soft-red focus border. Use for all text/number entry.

```jsx
<Input label="Descrição" placeholder="Ex. Licença de software" />
<Input label="Taxa de câmbio" value="0,18567" readOnly mono
       suffix={<Badge status="approved">ao vivo ✓</Badge>} />
```

Props: `label`, `hint`, `readOnly` (auto-fetched / calculated values), `prefix` / `suffix` adornments, `mono` for tabular monetary figures. Pair `readOnly` + `suffix` for the live exchange-rate pattern.
