import React from 'react';

/**
 * Payravel Button.
 * Flat, no shadow. Primary = solid red; ghost = transparent w/ hairline;
 * danger = solid rejected-red. Hover darkens (primary) or lifts surface (ghost).
 */
export function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  fullWidth = false,
  iconLeft = null,
  iconRight = null,
  children,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);

  const sizes = {
    sm: { padding: '0 12px', height: 32, fontSize: 13 },
    md: { padding: '0 16px', height: 38, fontSize: 14 },
    lg: { padding: '0 20px', height: 44, fontSize: 15 },
  };

  const palettes = {
    primary: {
      base: { background: 'var(--red-500)', color: 'var(--on-accent)', border: '0.5px solid transparent' },
      hover: { background: 'var(--red-600)' },
      active: { background: 'var(--red-700)' },
    },
    ghost: {
      base: { background: 'transparent', color: 'var(--text-primary)', border: '0.5px solid var(--border-default)' },
      hover: { background: 'var(--bg-input-hover)', border: '0.5px solid var(--border-strong)' },
      active: { background: 'var(--bg-input)' },
    },
    danger: {
      base: { background: 'var(--status-rejected-fg)', color: '#fff', border: '0.5px solid transparent' },
      hover: { background: '#d83a3a' },
      active: { background: '#c23030' },
    },
  };

  const p = palettes[variant] || palettes.primary;
  const s = sizes[size] || sizes.md;

  const styleObj = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: s.height,
    padding: s.padding,
    width: fullWidth ? '100%' : 'auto',
    fontFamily: 'var(--font-sans)',
    fontSize: s.fontSize,
    fontWeight: 'var(--weight-medium)',
    lineHeight: 1,
    borderRadius: 'var(--radius-sm)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.4 : 1,
    transition: 'background 120ms ease, border-color 120ms ease',
    whiteSpace: 'nowrap',
    ...p.base,
    ...(!disabled && hover ? p.hover : {}),
    ...(!disabled && active ? p.active : {}),
    ...style,
  };

  return (
    <button
      type="button"
      disabled={disabled}
      style={styleObj}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => { setHover(false); setActive(false); }}
      onMouseDown={() => setActive(true)}
      onMouseUp={() => setActive(false)}
      {...rest}
    >
      {iconLeft}
      {children}
      {iconRight}
    </button>
  );
}
