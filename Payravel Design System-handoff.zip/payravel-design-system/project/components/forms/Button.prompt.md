**Button** — the primary action control; solid red for primary actions, ghost for secondary, danger for destructive.

```jsx
<Button variant="primary">Enviar para aprovação</Button>
<Button variant="ghost">Cancelar</Button>
<Button variant="danger" size="sm">Rejeitar</Button>
```

Variants: `primary` (solid #CC0000), `ghost` (transparent + hairline), `danger` (solid rejected-red). Sizes `sm | md | lg`. Supports `fullWidth`, `disabled`, and `iconLeft` / `iconRight` nodes. Flat — never add a drop shadow.
