import * as React from 'react';

export interface SelectOption {
  value: string;
  label: string;
  /** Optional flag glyph (emoji) shown before the label — used for currencies. */
  flag?: string;
  /** Optional right-aligned meta (e.g. currency code). */
  meta?: string;
}

export interface SelectProps {
  label?: React.ReactNode;
  value?: string;
  onChange?: (value: string) => void;
  options: SelectOption[];
  placeholder?: string;
  disabled?: boolean;
  style?: React.CSSProperties;
}

/** Custom dropdown that can render flag glyphs — the currency picker. */
export function Select(props: SelectProps): JSX.Element;
