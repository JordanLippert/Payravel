import React from 'react';

/**
 * Payravel text input. Faint translucent fill, hairline border that warms to
 * soft red on hover/focus. Supports label, readonly state, and a trailing
 * adornment (e.g. a "ao vivo ✓" badge or a EUR suffix).
 */
export function Input({
  label = null,
  hint = null,
  value,
  placeholder = '',
  readOnly = false,
  disabled = false,
  type = 'text',
  prefix = null,
  suffix = null,
  mono = false,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [focus, setFocus] = React.useState(false);

  const borderColor = focus || hover ? 'var(--red-border)' : 'var(--border-default)';

  return (
    <label style={{ display: 'flex', flexDirection: 'column', gap: 6, ...style }}>
      {label && (
        <span style={{
          fontSize: 12, fontWeight: 'var(--weight-medium)',
          color: 'var(--text-tertiary)', fontFamily: 'var(--font-sans)',
        }}>{label}</span>
      )}
      <div
        style={{
          display: 'flex', alignItems: 'center', gap: 8,
          background: readOnly ? 'rgba(255,255,255,0.02)' : 'var(--bg-input)',
          border: `0.5px solid ${readOnly ? 'var(--border-default)' : borderColor}`,
          borderRadius: 'var(--radius-sm)',
          padding: '0 12px', height: 38,
          opacity: disabled ? 0.4 : 1,
          transition: 'border-color 120ms ease',
        }}
        onMouseEnter={() => setHover(true)}
        onMouseLeave={() => setHover(false)}
      >
        {prefix && <span style={{ color: 'var(--text-tertiary)', fontSize: 14, display: 'inline-flex' }}>{prefix}</span>}
        <input
          type={type}
          value={value}
          placeholder={placeholder}
          readOnly={readOnly}
          disabled={disabled}
          onFocus={() => setFocus(true)}
          onBlur={() => setFocus(false)}
          style={{
            flex: 1, minWidth: 0,
            background: 'transparent', border: 'none', outline: 'none',
            color: 'var(--text-primary)',
            fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
            fontSize: 14, fontWeight: 'var(--weight-regular)',
            fontVariantNumeric: mono ? 'tabular-nums' : 'normal',
          }}
          {...rest}
        />
        {suffix && <span style={{ display: 'inline-flex', alignItems: 'center', flex: 'none' }}>{suffix}</span>}
      </div>
      {hint && (
        <span style={{ fontSize: 12, color: 'var(--text-muted)', fontFamily: 'var(--font-sans)' }}>{hint}</span>
      )}
    </label>
  );
}
