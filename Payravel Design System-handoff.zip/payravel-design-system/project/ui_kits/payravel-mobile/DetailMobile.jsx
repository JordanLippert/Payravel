/* Payravel Mobile — Detalhe da requisição. Amount hero + info + timeline. */

function DetailMobile({ request, onBack = () => {} }) {
  const r = request || window.PAYRAVEL_DATA.requests[0];
  const s = (window.PV_STATUS_M || {})[r.status] || {};

  const timeline = [
    { label: 'Requisição criada', time: `${r.date} · 14:32`, done: true },
    { label: 'Enviada para aprovação', time: `${r.date} · 14:32`, done: true },
    r.status === 'approved'
      ? { label: 'Aprovada por Financeiro', time: '09 jun · 10:05', tone: 'approved' }
      : r.status === 'rejected'
      ? { label: 'Rejeitada por Financeiro', time: '09 jun · 11:20', tone: 'rejected' }
      : r.status === 'expired'
      ? { label: 'Expirada sem revisão', time: '08 jun · 23:59', tone: 'expired' }
      : { label: 'Aguardando revisão', time: 'Prazo: 24h', tone: 'pending', pending: true },
  ];

  return (
    <div style={{ minHeight: '100%' }}>
      {/* Header */}
      <div style={{ padding: '6px 16px 0', display: 'flex', alignItems: 'center', gap: 8, height: 46 }}>
        <button onClick={onBack} style={{ background: 'var(--bg-input)', border: '0.5px solid var(--border-default)', borderRadius: 11, width: 38, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
          <PvIcon name="chevronLeft" size={20} color="var(--text-primary)" />
        </button>
        <span style={{ fontSize: 14, color: 'var(--text-tertiary)', fontFamily: 'var(--font-mono)' }}>{r.id}</span>
      </div>

      <div style={{ padding: '14px 20px 28px', display: 'flex', flexDirection: 'column', gap: 22 }}>
        {/* Amount hero */}
        <div style={{ textAlign: 'center', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 12 }}>
          <span style={{ width: 56, height: 56, borderRadius: 18, background: 'var(--bg-input)', border: '0.5px solid var(--border-default)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28 }}>{r.flag}</span>
          <div>
            <div style={{ fontSize: 14, color: 'var(--text-tertiary)' }}>{r.desc}</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 46, fontWeight: 500, letterSpacing: '-0.02em', color: 'var(--text-primary)', marginTop: 6, lineHeight: 1.05 }}>€ {r.eur}</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 14, color: 'var(--text-muted)', marginTop: 4 }}>{r.cur} {r.local}</div>
          </div>
          <PvStatusChip status={r.status} />
        </div>

        {/* Info */}
        <div style={{ background: 'var(--surface-card)', border: '0.5px solid var(--border-subtle)', borderRadius: 16, overflow: 'hidden' }}>
          {[
            ['Moeda original', `${r.flag} ${r.cur}`],
            ['Valor local', `${r.cur} ${r.local}`],
            ['Equivalente em EUR', `€ ${r.eur}`],
            ['Taxa de câmbio', r.rate],
            ['Fonte da taxa', 'ECB · ao vivo'],
            ['Solicitante', r.employee],
          ].map(([k, v], i, a) => (
            <div key={k} style={{ display: 'flex', justifyContent: 'space-between', gap: 12, padding: '14px 16px', borderBottom: i < a.length - 1 ? '0.5px solid var(--border-subtle)' : 'none' }}>
              <span style={{ fontSize: 13.5, color: 'var(--text-tertiary)' }}>{k}</span>
              <span style={{ fontSize: 13.5, color: 'var(--text-primary)', fontWeight: 500, fontFamily: k.includes('Taxa') || k.includes('EUR') || k.includes('Valor') ? 'var(--font-mono)' : 'var(--font-sans)', textAlign: 'right' }}>{v}</span>
            </div>
          ))}
        </div>

        {/* Timeline */}
        <div>
          <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--text-primary)', marginBottom: 14 }}>Histórico</div>
          <div style={{ display: 'flex', flexDirection: 'column' }}>
            {timeline.map((t, i, a) => {
              const c = t.tone ? `var(--status-${t.tone}-fg)` : 'var(--red-500)';
              const last = i === a.length - 1;
              return (
                <div key={i} style={{ display: 'flex', gap: 14 }}>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <span style={{ width: 22, height: 22, borderRadius: 999, flex: 'none', display: 'flex', alignItems: 'center', justifyContent: 'center', background: t.pending ? 'transparent' : c, border: `1.5px solid ${c}` }}>
                      {!t.pending && <PvIcon name={t.tone === 'rejected' ? 'x' : 'check'} size={12} color="#fff" strokeWidth={2.6} />}
                    </span>
                    {!last && <span style={{ width: '1.5px', flex: 1, minHeight: 30, background: 'var(--border-default)' }} />}
                  </div>
                  <div style={{ paddingBottom: last ? 0 : 20, marginTop: 1 }}>
                    <div style={{ fontSize: 14, color: 'var(--text-primary)', fontWeight: t.tone ? 500 : 400 }}>{t.label}</div>
                    <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{t.time}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

window.DetailMobile = DetailMobile;
