/* Payravel Mobile — shared content bits: status colors, RequestCard. */
const STATUS_M = {
  pending: { fg: 'var(--status-pending-fg)', bg: 'var(--status-pending-bg)', bd: 'var(--status-pending-border)', label: 'Pendente' },
  approved: { fg: 'var(--status-approved-fg)', bg: 'var(--status-approved-bg)', bd: 'var(--status-approved-border)', label: 'Aprovado' },
  rejected: { fg: 'var(--status-rejected-fg)', bg: 'var(--status-rejected-bg)', bd: 'var(--status-rejected-border)', label: 'Rejeitado' },
  expired: { fg: 'var(--status-expired-fg)', bg: 'var(--status-expired-bg)', bd: 'var(--status-expired-border)', label: 'Expirado' },
};

function StatusChip({ status }) {
  const s = STATUS_M[status] || STATUS_M.pending;
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: 5, padding: '3px 9px', borderRadius: 999,
      fontSize: 11.5, fontWeight: 500, color: s.fg, background: s.bg, border: `0.5px solid ${s.bd}`,
      fontFamily: 'var(--font-sans)', whiteSpace: 'nowrap',
    }}>
      <span style={{ width: 5, height: 5, borderRadius: 999, background: s.fg }} />{s.label}
    </span>
  );
}

/* RequestCard — stacked, app-style. Flag tile + desc + amounts + status. */
function RequestCard({ req, onClick, showEmployee = false }) {
  return (
    <button onClick={onClick} style={{
      width: '100%', textAlign: 'left', cursor: 'pointer',
      background: 'var(--surface-card)', border: '0.5px solid var(--border-subtle)',
      borderRadius: 16, padding: 16, display: 'flex', flexDirection: 'column', gap: 12,
      fontFamily: 'var(--font-sans)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <span style={{
          width: 40, height: 40, borderRadius: 12, flex: 'none',
          background: 'var(--bg-input)', border: '0.5px solid var(--border-default)',
          display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20,
        }}>{req.flag}</span>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14.5, fontWeight: 500, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{req.desc}</div>
          <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>
            {showEmployee ? req.employee : req.id} · {req.date || req.expires}
          </div>
        </div>
        {req.status ? <StatusChip status={req.status} /> : null}
      </div>
      <div style={{ height: '0.5px', background: 'var(--border-subtle)' }} />
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>{req.cur} · valor local</div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 15, color: 'var(--text-secondary)', fontVariantNumeric: 'tabular-nums', marginTop: 2 }}>{req.local}</div>
        </div>
        <div style={{ textAlign: 'right' }}>
          <div style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>em EUR</div>
          <div style={{ fontFamily: 'var(--font-mono)', fontSize: 17, fontWeight: 500, color: 'var(--text-primary)', fontVariantNumeric: 'tabular-nums', marginTop: 2 }}>€ {req.eur}</div>
        </div>
      </div>
    </button>
  );
}

Object.assign(window, { PvStatusChip: StatusChip, PvRequestCard: RequestCard, PV_STATUS_M: STATUS_M });
