/* Payravel Mobile — Nova requisição (fluxo 3 passos + câmbio ao vivo). */
const PvNS_new = window.PayravelDesignSystem_6c6388 || {};
const { Input: PvInputN, Button: PvBtnN } = PvNS_new;

function TopBarFlow({ title, onBack, step, total }) {
  return (
    <div style={{ position: 'sticky', top: 0, zIndex: 5, background: 'var(--bg-base)', padding: '6px 16px 14px' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, height: 40 }}>
        <button onClick={onBack} style={{ background: 'var(--bg-input)', border: '0.5px solid var(--border-default)', borderRadius: 11, width: 38, height: 38, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer' }}>
          <PvIcon name="chevronLeft" size={20} color="var(--text-primary)" />
        </button>
        <span style={{ fontSize: 16, fontWeight: 500, color: 'var(--text-primary)' }}>{title}</span>
        <span style={{ marginLeft: 'auto', fontSize: 12.5, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)' }}>{step}/{total}</span>
      </div>
      <div style={{ display: 'flex', gap: 6, marginTop: 12 }}>
        {Array.from({ length: total }).map((_, i) => (
          <span key={i} style={{ flex: 1, height: 3, borderRadius: 999, background: i < step ? 'var(--red-500)' : 'var(--border-default)', transition: 'background 200ms ease' }} />
        ))}
      </div>
    </div>
  );
}

function CurrencySheet({ value, onPick }) {
  const { currencies } = window.PAYRAVEL_DATA;
  const [open, setOpen] = React.useState(false);
  const sel = currencies.find((c) => c.value === value) || currencies[0];
  return (
    <div>
      <span style={{ fontSize: 12, fontWeight: 500, color: 'var(--text-tertiary)' }}>Moeda</span>
      <button onClick={() => setOpen(!open)} style={{
        width: '100%', marginTop: 6, display: 'flex', alignItems: 'center', gap: 10, cursor: 'pointer',
        height: 48, padding: '0 14px', background: 'var(--bg-input)', border: `0.5px solid ${open ? 'var(--red-border)' : 'var(--border-default)'}`,
        borderRadius: 12, fontFamily: 'var(--font-sans)',
      }}>
        <span style={{ fontSize: 22 }}>{sel.flag}</span>
        <span style={{ fontSize: 15, color: 'var(--text-primary)' }}>{sel.label}</span>
        <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 13, color: 'var(--text-muted)' }}>{sel.meta}</span>
        <PvIcon name="chevronDown" size={18} color="var(--text-muted)" />
      </button>
      {open && (
        <div style={{ marginTop: 8, background: 'var(--bg-elevated)', border: '0.5px solid var(--border-default)', borderRadius: 12, overflow: 'hidden' }}>
          {currencies.map((c) => (
            <button key={c.value} onClick={() => { onPick(c.value); setOpen(false); }} style={{
              width: '100%', display: 'flex', alignItems: 'center', gap: 10, padding: '12px 14px', cursor: 'pointer',
              background: c.value === value ? 'var(--bg-input-hover)' : 'transparent', border: 'none',
              borderBottom: '0.5px solid var(--border-subtle)', fontFamily: 'var(--font-sans)',
            }}>
              <span style={{ fontSize: 20 }}>{c.flag}</span>
              <span style={{ fontSize: 14.5, color: 'var(--text-primary)' }}>{c.label}</span>
              <span style={{ marginLeft: 'auto', fontFamily: 'var(--font-mono)', fontSize: 12.5, color: 'var(--text-muted)' }}>{c.meta}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function NewRequestMobile({ onCancel = () => {}, onSubmit = () => {} }) {
  const { currencies } = window.PAYRAVEL_DATA;
  const [step, setStep] = React.useState(1);
  const [desc, setDesc] = React.useState('Licença anual Figma');
  const [amount, setAmount] = React.useState('1.200,00');
  const [cur, setCur] = React.useState('USD');
  const rate = (currencies.find((c) => c.value === cur) || {}).rate || '0,9200';
  const eur = '1.104,00';

  return (
    <div style={{ minHeight: '100%', display: 'flex', flexDirection: 'column' }}>
      <TopBarFlow title="Nova requisição" onBack={step === 1 ? onCancel : () => setStep(step - 1)} step={step} total={3} />

      <div style={{ flex: 1, padding: '8px 18px 20px', display: 'flex', flexDirection: 'column', gap: 18 }}>
        {step === 1 && (
          <>
            <div>
              <div style={{ fontSize: 18, fontWeight: 500, color: 'var(--text-primary)' }}>Detalhes</div>
              <div style={{ fontSize: 13, color: 'var(--text-tertiary)', marginTop: 3 }}>O que você precisa reembolsar?</div>
            </div>
            <PvInputN label="Descrição" value={desc} onChange={(e) => setDesc(e.target.value)} />
            <div>
              <span style={{ fontSize: 12, fontWeight: 500, color: 'var(--text-tertiary)' }}>Valor</span>
              <div style={{ marginTop: 6, display: 'flex', alignItems: 'center', gap: 10, height: 56, padding: '0 16px', background: 'var(--bg-input)', border: '0.5px solid var(--border-default)', borderRadius: 12 }}>
                <span style={{ fontFamily: 'var(--font-mono)', fontSize: 18, color: 'var(--text-muted)' }}>{cur}</span>
                <input value={amount} onChange={(e) => setAmount(e.target.value)} style={{ flex: 1, minWidth: 0, background: 'none', border: 'none', outline: 'none', textAlign: 'right', fontFamily: 'var(--font-mono)', fontSize: 26, fontWeight: 500, color: 'var(--text-primary)', fontVariantNumeric: 'tabular-nums' }} />
              </div>
            </div>
            <CurrencySheet value={cur} onPick={setCur} />
          </>
        )}

        {step === 2 && (
          <>
            <div>
              <div style={{ fontSize: 18, fontWeight: 500, color: 'var(--text-primary)' }}>Câmbio</div>
              <div style={{ fontSize: 13, color: 'var(--text-tertiary)', marginTop: 3 }}>Taxa buscada automaticamente.</div>
            </div>
            <div style={{ background: 'var(--surface-card)', border: '0.5px solid var(--border-subtle)', borderRadius: 16, padding: 18, display: 'flex', flexDirection: 'column', gap: 16 }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <span style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>Taxa de câmbio</span>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, fontSize: 11.5, fontWeight: 500, color: 'var(--status-approved-fg)', background: 'var(--status-approved-bg)', border: '0.5px solid var(--status-approved-border)', borderRadius: 999, padding: '3px 9px' }}>
                  <PvIcon name="zap" size={12} color="var(--status-approved-fg)" fill="var(--status-approved-fg)" />ao vivo
                </span>
              </div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 30, fontWeight: 500, color: 'var(--text-primary)', fontVariantNumeric: 'tabular-nums' }}>1 {cur} = {rate} EUR</div>
              <div style={{ height: '0.5px', background: 'var(--border-subtle)' }} />
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Você envia</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 16, color: 'var(--text-secondary)', marginTop: 2 }}>{cur} {amount}</div>
                </div>
                <PvIcon name="arrowUpRight" size={18} color="var(--text-muted)" />
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)' }}>Equivale a</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 18, fontWeight: 500, color: 'var(--red-500)', marginTop: 2 }}>€ {eur}</div>
                </div>
              </div>
            </div>
            <div style={{ fontSize: 12, color: 'var(--text-muted)', display: 'flex', gap: 7, alignItems: 'center' }}>
              <PvIcon name="refresh" size={14} color="var(--text-muted)" />Fonte: European Central Bank · atualizado há 2 min
            </div>
          </>
        )}

        {step === 3 && (
          <>
            <div>
              <div style={{ fontSize: 18, fontWeight: 500, color: 'var(--text-primary)' }}>Revisão</div>
              <div style={{ fontSize: 13, color: 'var(--text-tertiary)', marginTop: 3 }}>Confirme antes de enviar.</div>
            </div>
            <div style={{ background: 'var(--surface-card)', border: '0.5px solid var(--border-subtle)', borderRadius: 16, padding: 18, textAlign: 'center' }}>
              <div style={{ fontSize: 12.5, color: 'var(--text-muted)' }}>Equivalente em EUR</div>
              <div style={{ fontFamily: 'var(--font-mono)', fontSize: 42, fontWeight: 500, letterSpacing: '-0.02em', color: 'var(--text-primary)', marginTop: 6 }}>€ {eur}</div>
              <div style={{ fontSize: 13, color: 'var(--text-tertiary)', marginTop: 4 }}>{cur} {amount} · taxa {rate}</div>
            </div>
            <div style={{ background: 'var(--surface-card)', border: '0.5px solid var(--border-subtle)', borderRadius: 16, overflow: 'hidden' }}>
              {[['Descrição', desc], ['Moeda', cur], ['Valor local', `${cur} ${amount}`], ['Fonte da taxa', 'ECB · ao vivo']].map(([k, v], i, a) => (
                <div key={k} style={{ display: 'flex', justifyContent: 'space-between', gap: 12, padding: '13px 16px', borderBottom: i < a.length - 1 ? '0.5px solid var(--border-subtle)' : 'none' }}>
                  <span style={{ fontSize: 13.5, color: 'var(--text-tertiary)' }}>{k}</span>
                  <span style={{ fontSize: 13.5, color: 'var(--text-primary)', fontWeight: 500, textAlign: 'right' }}>{v}</span>
                </div>
              ))}
            </div>
          </>
        )}
      </div>

      {/* Sticky actions */}
      <div style={{ position: 'sticky', bottom: 0, background: 'var(--bg-base)', borderTop: '0.5px solid var(--border-subtle)', padding: '14px 18px 22px', display: 'flex', gap: 10 }}>
        <PvBtnN variant="ghost" size="lg" onClick={step === 1 ? onCancel : () => setStep(step - 1)}>{step === 1 ? 'Cancelar' : 'Voltar'}</PvBtnN>
        <PvBtnN variant="primary" size="lg" fullWidth
          iconRight={step === 3 ? <PvIcon name="send" size={17} color="#fff" /> : <PvIcon name="chevronRight" size={18} color="#fff" />}
          onClick={() => (step === 3 ? onSubmit() : setStep(step + 1))}>
          {step === 3 ? 'Enviar para aprovação' : 'Continuar'}
        </PvBtnN>
      </div>
    </div>
  );
}

window.NewRequestMobile = NewRequestMobile;
