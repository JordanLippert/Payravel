/* Payravel Mobile — Home (dashboard do funcionário). */
const PvNS_home = window.PayravelDesignSystem_6c6388 || {};
const { Avatar: PvAvatarH } = PvNS_home;

function HomeMobile({ onOpen = () => {}, onNew = () => {} }) {
  const { requests } = window.PAYRAVEL_DATA;
  const [filter, setFilter] = React.useState('all');
  const filters = [['all', 'Todas'], ['pending', 'Pendente'], ['approved', 'Aprovado'], ['rejected', 'Rejeitado']];
  const list = filter === 'all' ? requests : requests.filter((r) => r.status === filter);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20, padding: '8px 18px 28px' }}>
      {/* Greeting */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>Bem-vinda de volta,</div>
          <div style={{ fontSize: 20, fontWeight: 500, color: 'var(--text-primary)', marginTop: 2 }}>Marina Alves</div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
          <button style={{ background: 'var(--bg-input)', border: '0.5px solid var(--border-default)', borderRadius: 12, width: 40, height: 40, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', position: 'relative' }}>
            <PvIcon name="bell" size={20} color="var(--text-secondary)" />
            <span style={{ position: 'absolute', top: 9, right: 10, width: 7, height: 7, borderRadius: 999, background: 'var(--red-500)', border: '1.5px solid var(--bg-base)' }} />
          </button>
          <PvAvatarH name="Marina Alves" size={40} />
        </div>
      </div>

      {/* Balance hero */}
      <div style={{
        background: 'var(--surface-card)', border: '0.5px solid var(--border-subtle)',
        borderRadius: 20, padding: 22, position: 'relative', overflow: 'hidden',
      }}>
        <span style={{ position: 'absolute', left: 0, top: 0, bottom: 0, width: 3, background: 'var(--red-500)' }} />
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <span style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>Total enviado em junho</span>
          <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 12, color: 'var(--status-approved-fg)' }}>
            <PvIcon name="arrowUpRight" size={14} color="var(--status-approved-fg)" />12%
          </span>
        </div>
        <div style={{ fontFamily: 'var(--font-mono)', fontSize: 40, fontWeight: 500, letterSpacing: '-0.02em', color: 'var(--text-primary)', fontVariantNumeric: 'tabular-nums', marginTop: 10 }}>€ 3.408<span style={{ fontSize: 22, color: 'var(--text-tertiary)' }}>,40</span></div>
        <div style={{ fontSize: 12.5, color: 'var(--text-muted)', marginTop: 6 }}>convertido de 4 moedas · 5 requisições</div>
      </div>

      {/* Quick stats */}
      <div style={{ display: 'flex', gap: 10 }}>
        {[['Pendente', '1', 'var(--status-pending-fg)'], ['Aprovado', '2', 'var(--status-approved-fg)'], ['Rejeitado', '1', 'var(--status-rejected-fg)']].map(([l, v, c]) => (
          <div key={l} style={{ flex: 1, background: 'var(--surface-card)', border: '0.5px solid var(--border-subtle)', borderRadius: 14, padding: '13px 14px' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 500, color: c, lineHeight: 1 }}>{v}</div>
            <div style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 7 }}>{l}</div>
          </div>
        ))}
      </div>

      {/* Filter + list */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginTop: 2 }}>
        <span style={{ fontSize: 15, fontWeight: 500, color: 'var(--text-primary)' }}>Requisições recentes</span>
      </div>
      <div style={{ display: 'flex', gap: 8, overflowX: 'auto', margin: '-4px -18px 0', padding: '4px 18px' }}>
        {filters.map(([id, lbl]) => (
          <button key={id} onClick={() => setFilter(id)} style={{
            flex: 'none', padding: '7px 14px', borderRadius: 999, cursor: 'pointer',
            fontFamily: 'var(--font-sans)', fontSize: 13, fontWeight: 500, whiteSpace: 'nowrap',
            background: filter === id ? 'var(--text-primary)' : 'var(--bg-input)',
            color: filter === id ? '#000' : 'var(--text-tertiary)',
            border: `0.5px solid ${filter === id ? 'transparent' : 'var(--border-default)'}`,
          }}>{lbl}</button>
        ))}
      </div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {list.map((r) => <PvRequestCard key={r.id} req={r} onClick={() => onOpen(r)} />)}
        {list.length === 0 && <div style={{ textAlign: 'center', color: 'var(--text-muted)', fontSize: 13, padding: '24px 0' }}>Nenhuma requisição neste filtro.</div>}
      </div>
    </div>
  );
}

window.HomeMobile = HomeMobile;
