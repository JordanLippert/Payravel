/* Payravel Mobile — Painel financeiro (role: finance). */

function FinanceMobile({ onOpen = () => {} }) {
  const { financeQueue } = window.PAYRAVEL_DATA;
  const [done, setDone] = React.useState({}); // id -> 'approved' | 'rejected'

  const metrics = [
    { label: 'Aguardando revisão', value: '4', tone: 'var(--status-pending-fg)' },
    { label: 'Total em EUR', value: '€ 2.758', tone: 'var(--text-primary)' },
    { label: 'Aprovados hoje', value: '7', tone: 'var(--status-approved-fg)' },
    { label: 'Expiram em 24h', value: '2', tone: 'var(--status-rejected-fg)' },
  ];

  return (
    <div style={{ padding: '8px 18px 28px', display: 'flex', flexDirection: 'column', gap: 20 }}>
      {/* Header w/ finance role pill */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div>
          <div style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>Painel</div>
          <div style={{ fontSize: 20, fontWeight: 500, color: 'var(--text-primary)', marginTop: 2 }}>Aprovações</div>
        </div>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '5px 12px 5px 5px', borderRadius: 999, background: 'var(--red-500)' }}>
          <span style={{ width: 26, height: 26, borderRadius: 999, background: 'rgba(0,0,0,0.25)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
            <PvIcon name="shield" size={15} color="#fff" />
          </span>
          <span style={{ display: 'flex', flexDirection: 'column', lineHeight: 1.15 }}>
            <span style={{ fontSize: 12.5, fontWeight: 500, color: '#fff' }}>Lucas Costa</span>
            <span style={{ fontSize: 10.5, color: 'rgba(255,255,255,0.82)' }}>Finance</span>
          </span>
        </span>
      </div>

      {/* Metrics 2x2 */}
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        {metrics.map((m) => (
          <div key={m.label} style={{ background: 'var(--surface-card)', border: '0.5px solid var(--border-subtle)', borderRadius: 14, padding: '14px 16px' }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: 22, fontWeight: 500, color: m.tone, lineHeight: 1 }}>{m.value}</div>
            <div style={{ fontSize: 12, color: 'var(--text-tertiary)', marginTop: 7 }}>{m.label}</div>
          </div>
        ))}
      </div>

      <div style={{ fontSize: 15, fontWeight: 500, color: 'var(--text-primary)' }}>Fila de revisão</div>

      <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
        {financeQueue.map((q) => {
          const resolved = done[q.id];
          const critical = q.critical && !resolved;
          const critColor = q.expires.includes('h') ? 'var(--status-rejected-fg)' : 'var(--status-pending-fg)';
          return (
            <div key={q.id} style={{
              background: 'var(--surface-card)',
              border: `0.5px solid ${critical ? critColor : 'var(--border-subtle)'}`,
              borderRadius: 16, padding: 16, display: 'flex', flexDirection: 'column', gap: 14,
              opacity: resolved ? 0.55 : 1, transition: 'opacity 200ms ease',
            }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
                <span style={{ width: 40, height: 40, borderRadius: 12, flex: 'none', background: 'var(--bg-input)', border: '0.5px solid var(--border-default)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20 }}>{q.flag}</span>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 14.5, fontWeight: 500, color: 'var(--text-primary)', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{q.desc}</div>
                  <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{q.employee}</div>
                </div>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4, fontSize: 11.5, fontWeight: 500, color: critical ? critColor : 'var(--text-muted)', background: critical ? 'color-mix(in srgb, ' + critColor + ' 12%, transparent)' : 'var(--bg-input)', border: `0.5px solid ${critical ? critColor : 'var(--border-default)'}`, borderRadius: 999, padding: '3px 8px' }}>
                  <PvIcon name="clock" size={12} color={critical ? critColor : 'var(--text-muted)'} />{q.expires}
                </span>
              </div>
              <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontSize: 11.5, color: 'var(--text-muted)' }}>{q.cur} {q.local}</div>
                  <div style={{ fontFamily: 'var(--font-mono)', fontSize: 19, fontWeight: 500, color: 'var(--text-primary)', marginTop: 2 }}>€ {q.eur}</div>
                </div>
                {resolved ? (
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6, fontSize: 13, fontWeight: 500, color: `var(--status-${resolved}-fg)` }}>
                    <PvIcon name={resolved === 'approved' ? 'check' : 'x'} size={16} color={`var(--status-${resolved}-fg)`} strokeWidth={2.4} />
                    {resolved === 'approved' ? 'Aprovado' : 'Rejeitado'}
                  </span>
                ) : (
                  <div style={{ display: 'flex', gap: 8 }}>
                    <button onClick={() => setDone({ ...done, [q.id]: 'rejected' })} style={{ width: 42, height: 42, borderRadius: 12, cursor: 'pointer', background: 'var(--status-rejected-bg)', border: '0.5px solid var(--status-rejected-border)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <PvIcon name="x" size={18} color="var(--status-rejected-fg)" strokeWidth={2.2} />
                    </button>
                    <button onClick={() => setDone({ ...done, [q.id]: 'approved' })} style={{ width: 42, height: 42, borderRadius: 12, cursor: 'pointer', background: 'var(--status-approved-bg)', border: '0.5px solid var(--status-approved-border)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                      <PvIcon name="check" size={18} color="var(--status-approved-fg)" strokeWidth={2.2} />
                    </button>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

window.FinanceMobile = FinanceMobile;
