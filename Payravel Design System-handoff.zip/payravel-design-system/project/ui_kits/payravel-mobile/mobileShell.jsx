/* Payravel Mobile — shared shell: Icon (Lucide paths), StatusBar, PhoneFrame, BottomNav.
   Icons use Lucide path data (the system's recommended set) — stroke 1.8, round joins. */

const LUCIDE = {
  home: ['m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z', 'M9 22V12h6v10'],
  receipt: ['M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z', 'M16 8H8', 'M16 12H8', 'M11 16H8'],
  clock: ['M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z', 'M12 6v6l4 2'],
  user: ['M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2', 'M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z'],
  plus: ['M5 12h14', 'M12 5v14'],
  chevronLeft: ['m15 18-6-6 6-6'],
  chevronRight: ['m9 18 6-6-6-6'],
  chevronDown: ['m6 9 6 6 6-6'],
  check: ['M20 6 9 17l-5-5'],
  x: ['M18 6 6 18', 'm6 6 12 12'],
  bell: ['M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9', 'M10.3 21a1.94 1.94 0 0 0 3.4 0'],
  arrowUpRight: ['M7 7h10v10', 'M7 17 17 7'],
  shield: ['M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z', 'm9 12 2 2 4-4'],
  search: ['M11 3a8 8 0 1 0 0 16 8 8 0 0 0 0-16z', 'm21 21-4.3-4.3'],
  calendar: ['M8 2v4', 'M16 2v4', 'M3 6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z', 'M3 10h18'],
  refresh: ['M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8', 'M3 3v5h5', 'M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16', 'M21 21v-5h-5'],
  zap: ['M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z'],
  send: ['M14.5 2.5 9 14l-3.5 3.5L2 22l4.5-1.5L18 9z', 'm22 2-7 20-4-9-9-4z'],
  alert: ['M12 9v4', 'M12 17h.01', 'M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'],
  logout: ['M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4', 'M16 17l5-5-5-5', 'M21 12H9'],
  filter: ['M22 3H2l8 9.46V19l4 2v-8.54z'],
};

function Icon({ name, size = 22, color = 'currentColor', strokeWidth = 1.8, fill = 'none', style = {} }) {
  const paths = LUCIDE[name] || [];
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke={color} strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round"
      style={{ display: 'block', flex: 'none', ...style }}>
      {paths.map((d, i) => <path key={i} d={d} fill={fill === 'currentColor' ? color : fill} />)}
    </svg>
  );
}

function StatusBar({ dark = false }) {
  const fg = dark ? '#fff' : 'var(--text-primary)';
  return (
    <div style={{
      height: 44, display: 'flex', alignItems: 'center', justifyContent: 'space-between',
      padding: '0 22px 0 26px', flex: 'none', color: fg,
      fontFamily: 'var(--font-sans)',
    }}>
      <span style={{ fontSize: 15, fontWeight: 600, letterSpacing: '0.02em' }}>9:41</span>
      <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        {/* signal */}
        <svg width="18" height="12" viewBox="0 0 18 12" fill={fg}><rect x="0" y="8" width="3" height="4" rx="1"/><rect x="5" y="5" width="3" height="7" rx="1"/><rect x="10" y="2.5" width="3" height="9.5" rx="1"/><rect x="15" y="0" width="3" height="12" rx="1"/></svg>
        {/* wifi */}
        <svg width="17" height="12" viewBox="0 0 17 12" fill="none" stroke={fg} strokeWidth="1.6" strokeLinecap="round"><path d="M1.5 4.2a11 11 0 0 1 14 0"/><path d="M4.2 7a7 7 0 0 1 8.6 0"/><path d="M6.9 9.6a3 3 0 0 1 3.2 0"/></svg>
        {/* battery */}
        <svg width="26" height="13" viewBox="0 0 26 13" fill="none"><rect x="0.5" y="0.5" width="22" height="12" rx="3" stroke={fg} strokeOpacity="0.4"/><rect x="2" y="2" width="17" height="9" rx="1.5" fill={fg}/><rect x="24" y="4" width="1.6" height="5" rx="0.8" fill={fg} fillOpacity="0.4"/></svg>
      </span>
    </div>
  );
}

const TABS = [
  { id: 'home', label: 'Início', icon: 'home' },
  { id: 'requests', label: 'Requisições', icon: 'receipt' },
  { id: 'fab', label: '', icon: 'plus' },
  { id: 'finance', label: 'Financeiro', icon: 'shield' },
  { id: 'profile', label: 'Perfil', icon: 'user' },
];

function BottomNav({ active = 'home', onTab = () => {}, onFab = () => {} }) {
  return (
    <div style={{
      flex: 'none', position: 'relative',
      background: 'rgba(20,20,20,0.92)', backdropFilter: 'blur(12px)',
      borderTop: '0.5px solid var(--border-subtle)',
      padding: '8px 12px 26px',
      display: 'flex', alignItems: 'flex-start', justifyContent: 'space-between',
    }}>
      {TABS.map((t) => {
        if (t.id === 'fab') {
          return (
            <button key="fab" onClick={onFab} style={{
              width: 52, height: 52, marginTop: -22, borderRadius: 18,
              background: 'var(--red-500)', border: 'none', cursor: 'pointer',
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              boxShadow: '0 6px 18px rgba(204,0,0,0.45)', flex: 'none',
            }}>
              <Icon name="plus" size={26} color="#fff" strokeWidth={2.4} />
            </button>
          );
        }
        const on = active === t.id;
        return (
          <button key={t.id} onClick={() => onTab(t.id)} style={{
            background: 'none', border: 'none', cursor: 'pointer',
            display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 4,
            width: 60, padding: 0,
          }}>
            <Icon name={t.icon} size={22} color={on ? 'var(--red-500)' : 'var(--text-muted)'} strokeWidth={on ? 2.2 : 1.8} />
            <span style={{ fontSize: 10.5, fontWeight: 500, color: on ? 'var(--text-primary)' : 'var(--text-muted)', fontFamily: 'var(--font-sans)' }}>{t.label}</span>
          </button>
        );
      })}
    </div>
  );
}

/* PhoneFrame — a bezel-less 390-wide screen, centered on the canvas. */
function PhoneFrame({ children, dark = false, showNav = true, activeTab = 'home', onTab, onFab, scrollKey }) {
  const scrollRef = React.useRef(null);
  React.useEffect(() => { if (scrollRef.current) scrollRef.current.scrollTop = 0; }, [scrollKey]);
  return (
    <div style={{
      width: 390, height: 844, flex: 'none',
      background: 'var(--bg-base)',
      borderRadius: 44, border: '0.5px solid var(--border-default)',
      overflow: 'hidden', position: 'relative',
      display: 'flex', flexDirection: 'column',
      boxShadow: '0 24px 70px rgba(0,0,0,0.6)',
    }}>
      <StatusBar dark={dark} />
      <div ref={scrollRef} style={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', position: 'relative' }}>
        {children}
      </div>
      {showNav && <BottomNav active={activeTab} onTab={onTab} onFab={onFab} />}
    </div>
  );
}

Object.assign(window, { PvIcon: Icon, PvStatusBar: StatusBar, PvBottomNav: BottomNav, PvPhoneFrame: PhoneFrame });
