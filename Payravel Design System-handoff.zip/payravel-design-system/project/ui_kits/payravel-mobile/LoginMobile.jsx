/* Payravel Mobile — Login / Registro. Red hero + dark sheet. */
const PvNS_login = window.PayravelDesignSystem_6c6388 || {};
const { Logo: PvLogoM, Button: PvBtnM, Input: PvInputM } = PvNS_login;

function LoginMobile({ onLogin = () => {} }) {
  const [mode, setMode] = React.useState('login');
  return (
    <div style={{ minHeight: '100%', display: 'flex', flexDirection: 'column', background: 'var(--red-500)' }}>
      {/* Red hero */}
      <div style={{ padding: '36px 28px 60px', display: 'flex', flexDirection: 'column', gap: 28, color: '#fff' }}>
        <PvLogoM size={40} color="#fff" knockout="#CC0000" wordmarkColor="#fff" />
        <div>
          <h1 style={{ fontSize: 32, fontWeight: 500, lineHeight: 1.12, letterSpacing: '-0.02em', margin: 0 }}>
            Pagamentos<br />multi-moeda,<br />sem fronteiras.
          </h1>
          <p style={{ fontSize: 15, lineHeight: 1.5, color: 'rgba(255,255,255,0.85)', marginTop: 14, maxWidth: 300 }}>
            Solicite, converta e acompanhe reembolsos — câmbio ao vivo, tudo em EUR.
          </p>
        </div>
      </div>

      {/* Dark sheet */}
      <div style={{
        flex: 1, background: 'var(--bg-base)', borderTopLeftRadius: 28, borderTopRightRadius: 28,
        marginTop: -24, padding: '30px 26px 36px',
        display: 'flex', flexDirection: 'column', gap: 22,
        borderTop: '0.5px solid var(--border-default)',
      }}>
        <div style={{ display: 'flex', gap: 6, background: 'var(--bg-input)', borderRadius: 12, padding: 4 }}>
          {[['login', 'Entrar'], ['register', 'Registrar']].map(([id, lbl]) => (
            <button key={id} onClick={() => setMode(id)} style={{
              flex: 1, padding: '10px 0', borderRadius: 9, border: 'none', cursor: 'pointer',
              background: mode === id ? 'var(--bg-elevated)' : 'transparent',
              color: mode === id ? 'var(--text-primary)' : 'var(--text-tertiary)',
              fontFamily: 'var(--font-sans)', fontSize: 14, fontWeight: 500,
              boxShadow: mode === id ? '0 1px 0 rgba(255,255,255,0.04)' : 'none',
            }}>{lbl}</button>
          ))}
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {mode === 'register' && <PvInputM label="Nome completo" placeholder="Marina Alves" />}
          <PvInputM label="E-mail" type="email" defaultValue="marina@empresa.com" placeholder="voce@empresa.com" />
          <PvInputM label="Senha" type="password" defaultValue="123456" placeholder="••••••••" />
        </div>

        <PvBtnM variant="primary" size="lg" fullWidth onClick={onLogin}>
          {mode === 'login' ? 'Entrar' : 'Criar conta'}
        </PvBtnM>

        <div style={{ fontSize: 13, color: 'var(--text-muted)', textAlign: 'center', marginTop: 'auto' }}>
          {mode === 'login' ? 'Esqueceu a senha? ' : 'Já tem conta? '}
          <span onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
            style={{ color: 'var(--text-secondary)', borderBottom: '0.5px solid var(--border-strong)' }}>
            {mode === 'login' ? 'Recuperar acesso' : 'Entrar'}
          </span>
        </div>
      </div>
    </div>
  );
}

window.LoginMobile = LoginMobile;
