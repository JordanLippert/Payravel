/* Payravel — Login / Registro. Split layout: red brand panel + dark form. */
const PvNS = window.PayravelDesignSystem_6c6388 || {};
const { Button: PvButton, Input: PvInput } = PvNS;
const PvLogo = PvNS.Logo || function FallbackLogo({ wordmarkColor = '#fff' }) {
  return <span style={{ fontSize: 22, fontWeight: 500, letterSpacing: '-0.01em', color: wordmarkColor }}>Payravel</span>;
};

function LoginScreen({ onLogin = () => {} }) {
  const [mode, setMode] = React.useState('login'); // 'login' | 'register'
  return (
    <div style={{ display: 'flex', height: '100%', minHeight: 600, background: 'var(--bg-base)' }}>
      {/* Left — brand panel */}
      <div style={{
        flex: '0 0 42%', background: 'var(--red-500)', color: '#fff',
        padding: '56px 48px', display: 'flex', flexDirection: 'column', justifyContent: 'space-between',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <PvLogo size={54} color="#fff" knockout="#CC0000" wordmarkColor="#fff" />
        </div>
        <div>
          <h1 style={{ fontSize: 40, fontWeight: 500, lineHeight: 1.12, letterSpacing: '-0.02em', margin: 0 }}>
            Pagamentos<br />multi-moeda,<br />sem fronteiras.
          </h1>
          <p style={{ fontSize: 16, lineHeight: 1.5, color: 'rgba(255,255,255,0.82)', marginTop: 20, maxWidth: 360 }}>
            Solicite, converta e aprove reembolsos da sua equipe global — câmbio ao vivo, tudo em EUR.
          </p>
        </div>
        <div style={{ fontSize: 13, color: 'rgba(255,255,255,0.7)' }}>© 2026 Payravel · Buzzvel</div>
      </div>

      {/* Right — form */}
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 40 }}>
        <div style={{ width: '100%', maxWidth: 360, display: 'flex', flexDirection: 'column', gap: 22 }}>
          <div>
            <h2 style={{ fontSize: 22, fontWeight: 500, color: 'var(--text-primary)', margin: 0 }}>
              {mode === 'login' ? 'Entrar na conta' : 'Criar conta'}
            </h2>
            <p style={{ fontSize: 14, color: 'var(--text-tertiary)', marginTop: 6 }}>
              {mode === 'login' ? 'Acesse seu painel de requisições.' : 'Comece a solicitar pagamentos hoje.'}
            </p>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {mode === 'register' && (
              <PvInput label="Nome completo" placeholder="Marina Alves" defaultValue="" />
            )}
            <PvInput label="E-mail" type="email" placeholder="voce@empresa.com" defaultValue="marina@empresa.com" />
            <PvInput label="Senha" type="password" placeholder="••••••••" defaultValue="123456" />
          </div>

          <div style={{ display: 'flex', gap: 10 }}>
            <PvButton variant="primary" fullWidth onClick={onLogin}>
              {mode === 'login' ? 'Entrar' : 'Registrar'}
            </PvButton>
            <PvButton variant="ghost" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
              {mode === 'login' ? 'Registrar' : 'Entrar'}
            </PvButton>
          </div>

          <div style={{ fontSize: 13, color: 'var(--text-muted)', textAlign: 'center' }}>
            {mode === 'login' ? 'Esqueceu a senha? ' : 'Já tem conta? '}
            <span
              onClick={() => setMode(mode === 'login' ? 'register' : 'login')}
              style={{ color: 'var(--text-secondary)', cursor: 'pointer', borderBottom: '0.5px solid var(--border-strong)' }}
            >{mode === 'login' ? 'Recuperar acesso' : 'Entrar'}</span>
          </div>
        </div>
      </div>
    </div>
  );
}

window.LoginScreen = LoginScreen;
