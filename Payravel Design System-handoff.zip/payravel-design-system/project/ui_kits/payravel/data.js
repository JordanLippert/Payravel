/* Shared mock data for the Payravel UI kit. Sets window.PAYRAVEL_DATA. */
(function () {
  const requests = [
    { id: 'PR-1042', desc: 'Licença anual Figma', local: '1.200,00', cur: 'USD', flag: '🇺🇸', eur: '1.104,00', rate: '0,9200', date: '08 jun 2026', status: 'pending', employee: 'Marina Alves' },
    { id: 'PR-1039', desc: 'Hospedagem AWS — maio', local: '3.480,00', cur: 'BRL', flag: '🇧🇷', eur: '646,28', rate: '0,1857', date: '06 jun 2026', status: 'approved', employee: 'João Pereira' },
    { id: 'PR-1037', desc: 'Consultoria UX (12h)', local: '980,00', cur: 'GBP', flag: '🇬🇧', eur: '1.146,60', rate: '1,1700', date: '05 jun 2026', status: 'approved', employee: 'Marina Alves' },
    { id: 'PR-1031', desc: 'Equipamento — monitor', local: '54.000', cur: 'JPY', flag: '🇯🇵', eur: '318,60', rate: '0,0059', date: '02 jun 2026', status: 'rejected', employee: 'Sofia Marques' },
    { id: 'PR-1024', desc: 'Domínio + SSL (3 anos)', local: '210,00', cur: 'USD', flag: '🇺🇸', eur: '193,20', rate: '0,9200', date: '24 mai 2026', status: 'expired', employee: 'João Pereira' },
  ];

  const financeQueue = [
    { id: 'PR-1042', desc: 'Licença anual Figma', employee: 'Marina Alves', local: '1.200,00', cur: 'USD', flag: '🇺🇸', eur: '1.104,00', expires: '4h', critical: true },
    { id: 'PR-1041', desc: 'Campanha Meta Ads', employee: 'Sofia Marques', local: '2.500,00', cur: 'BRL', flag: '🇧🇷', eur: '464,25', expires: '19h', critical: true },
    { id: 'PR-1040', desc: 'Plano Notion Team', employee: 'João Pereira', local: '480,00', cur: 'USD', flag: '🇺🇸', eur: '441,60', expires: '2d', critical: false },
    { id: 'PR-1038', desc: 'Tradução jurídica', employee: 'Marina Alves', local: '640,00', cur: 'GBP', flag: '🇬🇧', eur: '748,80', expires: '3d', critical: false },
  ];

  const currencies = [
    { value: 'USD', label: 'Dólar americano', flag: '🇺🇸', meta: 'USD', rate: '0,9200' },
    { value: 'BRL', label: 'Real brasileiro', flag: '🇧🇷', meta: 'BRL', rate: '0,1857' },
    { value: 'GBP', label: 'Libra esterlina', flag: '🇬🇧', meta: 'GBP', rate: '1,1700' },
    { value: 'JPY', label: 'Iene japonês', flag: '🇯🇵', meta: 'JPY', rate: '0,0059' },
  ];

  window.PAYRAVEL_DATA = { requests, financeQueue, currencies };
})();
