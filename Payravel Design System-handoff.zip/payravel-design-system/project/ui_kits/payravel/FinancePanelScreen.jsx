/* Payravel — Painel financeiro (role: finance). Fila de aprovação com ações inline. */
const FP = window.PayravelDesignSystem_6c6388;
const { Topbar: FpTopbar, MetricCard: FpMetric, Badge: FpBadge } = FP;

function ActionBtn({ kind, onClick }) {
  const isApprove = kind === 'approve';
  const [hover, setHover] = React.useState(false);
  const fg = isApprove ? 'var(--status-approved-fg)' : 'var(--status-rejected-fg)';
  const bg = isApprove ? 'var(--status-approved-bg)' : 'var(--status-rejected-bg)';
  const bd = isApprove ? 'var(--status-approved-border)' : 'var(--status-rejected-border)';
  return (
    <button
      type="button" onClick={onClick}
      onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}
      title={isApprove ? 'Aprovar' : 'Rejeitar'}
      style={{
        width: 30, height: 30, borderRadius: 6, cursor: 'pointer',
        display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 14, color: fg, background: hover ? bg : 'transparent',
        border: `0.5px solid ${hover ? bd : 'var(--border-default)'}`,
        transition: 'all 120ms ease', fontFamily: 'var(--font-sans)',
      }}
    >{isApprove ? '✓' : '✕'}</button>
  );
}

function FinancePanelScreen() {
  const [queue, setQueue] = React.useState(window.PAYRAVEL_DATA.financeQueue);
  const [resolved, setResolved] = React.useState({}); // id -> 'approved' | 'rejected'

  function resolve(id, status) {
    setResolved((r) => ({ ...r, [id]: status }));
    setTimeout(() => setQueue((q) => q.filter((x) => x.id !== id)), 900);
  }

  return (
    <div style={{ minHeight: 600, background: 'var(--bg-base)' }}>
      <FpTopbar
        user={{ name: 'Lucas Costa', role: 'Finance' }}
        nav={[{ label: 'Fila de aprovação', active: true }, { label: 'Histórico' }, { label: 'Relatórios' }]}
      />
      <div style={{ padding: 32, maxWidth: 1180, margin: '0 auto' }}>
        <h1 style={{ fontSize: 22, fontWeight: 500, color: 'var(--text-primary)', margin: '0 0 4px' }}>Painel financeiro</h1>
        <p style={{ fontSize: 14, color: 'var(--text-tertiary)', margin: '0 0 24px' }}>Revise e libere as requisições da equipe.</p>

        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 28 }}>
          <FpMetric label="Aguardando revisão" value={String(queue.length)} accent sub="na sua fila" />
          <FpMetric label="Total em EUR" value="€ 2.798" sub="valor pendente" />
          <FpMetric label="Aprovados hoje" value="7" tone="approved" sub="€ 5.120 liberados" />
          <FpMetric label="Expiram em 24h" value="2" tone="pending" sub="ação necessária" />
        </div>

        <div style={{ background: 'var(--surface-card)', border: '0.5px solid var(--border-subtle)', borderRadius: 8, overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '0.5px solid var(--border-subtle)', fontSize: 14, fontWeight: 500, color: 'var(--text-primary)' }}>
            Fila de aprovação
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '0.5px solid var(--border-subtle)' }}>
                <window.PvTh>Funcionário / Descrição</window.PvTh>
                <window.PvTh align="right">Valor local</window.PvTh>
                <window.PvTh>Moeda</window.PvTh>
                <window.PvTh align="right">Em EUR</window.PvTh>
                <window.PvTh>Expira</window.PvTh>
                <window.PvTh align="right">Ação</window.PvTh>
              </tr>
            </thead>
            <tbody>
              {queue.map((r, i) => {
                const res = resolved[r.id];
                const critical = r.critical && !res;
                return (
                  <tr key={r.id} style={{
                    borderBottom: i < queue.length - 1 ? '0.5px solid var(--border-subtle)' : 'none',
                    background: res ? (res === 'approved' ? 'var(--status-approved-bg)' : 'var(--status-rejected-bg)')
                      : critical ? 'var(--status-pending-bg)' : 'transparent',
                    transition: 'background 200ms ease',
                  }}>
                    <td style={{ padding: '14px 16px' }}>
                      <div style={{ fontSize: 14, color: 'var(--text-primary)' }}>{r.desc}</div>
                      <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2 }}>{r.employee} · {r.id}</div>
                    </td>
                    <td style={{ padding: '14px 16px', textAlign: 'right', fontFamily: 'var(--font-mono)', fontVariantNumeric: 'tabular-nums', fontSize: 14, color: 'var(--text-secondary)' }}>{r.local}</td>
                    <td style={{ padding: '14px 16px', fontSize: 14, color: 'var(--text-secondary)' }}><span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><span style={{ fontSize: 15 }}>{r.flag}</span>{r.cur}</span></td>
                    <td style={{ padding: '14px 16px', textAlign: 'right', fontFamily: 'var(--font-mono)', fontVariantNumeric: 'tabular-nums', fontSize: 14, color: 'var(--text-primary)' }}>€ {r.eur}</td>
                    <td style={{ padding: '14px 16px', fontSize: 13, color: critical ? 'var(--status-pending-fg)' : 'var(--text-tertiary)', fontFamily: 'var(--font-mono)' }}>
                      {critical && <span style={{ marginRight: 5 }}>⏱</span>}{r.expires}
                    </td>
                    <td style={{ padding: '14px 16px', textAlign: 'right' }}>
                      {res ? (
                        <FpBadge status={res} />
                      ) : (
                        <div style={{ display: 'inline-flex', gap: 6 }}>
                          <ActionBtn kind="approve" onClick={() => resolve(r.id, 'approved')} />
                          <ActionBtn kind="reject" onClick={() => resolve(r.id, 'rejected')} />
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
              {queue.length === 0 && (
                <tr><td colSpan={6} style={{ padding: '40px 16px', textAlign: 'center', color: 'var(--text-muted)', fontSize: 14 }}>Fila vazia — tudo revisado. ✓</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

window.FinancePanelScreen = FinancePanelScreen;
