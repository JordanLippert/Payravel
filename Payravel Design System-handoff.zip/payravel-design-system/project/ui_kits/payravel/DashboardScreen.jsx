/* Payravel — Dashboard do funcionário. Topbar + KPI cards + requests table. */
const { Topbar: DashTopbar, MetricCard: DashMetric, Badge: DashBadge, Button: DashButton } = window.PayravelDesignSystem_6c6388;

function Th({ children, align = 'left', w }) {
  return (
    <th style={{
      textAlign: align, padding: '0 16px 10px', fontSize: 11, letterSpacing: '0.04em',
      textTransform: 'uppercase', color: 'var(--text-muted)', fontWeight: 500, whiteSpace: 'nowrap', width: w,
    }}>{children}</th>
  );
}
function Td({ children, align = 'left', mono = false, color = 'var(--text-secondary)' }) {
  return (
    <td style={{
      padding: '14px 16px', fontSize: 14, textAlign: align, color,
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
      fontVariantNumeric: mono ? 'tabular-nums' : 'normal', whiteSpace: 'nowrap',
    }}>{children}</td>
  );
}

function DashboardScreen({ onNewRequest = () => {}, onOpenRequest = () => {} }) {
  const { requests } = window.PAYRAVEL_DATA;
  return (
    <div style={{ minHeight: 600, background: 'var(--bg-base)' }}>
      <DashTopbar
        user={{ name: 'Marina Alves' }}
        nav={[{ label: 'Dashboard', active: true }, { label: 'Requisições' }, { label: 'Histórico' }]}
      />
      <div style={{ padding: 32, maxWidth: 1180, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'space-between', marginBottom: 24 }}>
          <div>
            <h1 style={{ fontSize: 22, fontWeight: 500, color: 'var(--text-primary)', margin: 0 }}>Olá, Marina</h1>
            <p style={{ fontSize: 14, color: 'var(--text-tertiary)', marginTop: 4 }}>Suas requisições de pagamento deste mês.</p>
          </div>
          <DashButton variant="primary" onClick={onNewRequest} iconLeft={<span style={{ fontSize: 16, lineHeight: 0 }}>+</span>}>Nova requisição</DashButton>
        </div>

        {/* Metrics */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 28 }}>
          <DashMetric label="Total enviado" value="€ 3.408" sub="5 requisições" accent />
          <DashMetric label="Pendente" value="1" tone="pending" sub="€ 1.104 em revisão" />
          <DashMetric label="Aprovado" value="2" tone="approved" sub="€ 1.792 liberados" />
          <DashMetric label="Rejeitado" value="1" tone="rejected" sub="€ 318 recusados" />
        </div>

        {/* Table */}
        <div style={{ background: 'var(--surface-card)', border: '0.5px solid var(--border-subtle)', borderRadius: 8, overflow: 'hidden' }}>
          <div style={{ padding: '16px 20px', borderBottom: '0.5px solid var(--border-subtle)', fontSize: 14, fontWeight: 500, color: 'var(--text-primary)' }}>
            Requisições recentes
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ borderBottom: '0.5px solid var(--border-subtle)' }}>
                <Th>Descrição</Th><Th align="right">Valor local</Th><Th>Moeda</Th>
                <Th align="right">Em EUR</Th><Th>Data</Th><Th>Status</Th>
              </tr>
            </thead>
            <tbody>
              {requests.map((r, i) => (
                <tr key={r.id}
                  onClick={() => onOpenRequest(r)}
                  style={{ borderBottom: i < requests.length - 1 ? '0.5px solid var(--border-subtle)' : 'none', cursor: 'pointer', transition: 'background 120ms ease' }}
                  onMouseEnter={(e) => e.currentTarget.style.background = 'var(--bg-row-hover)'}
                  onMouseLeave={(e) => e.currentTarget.style.background = 'transparent'}
                >
                  <Td color="var(--text-primary)">{r.desc}</Td>
                  <Td align="right" mono>{r.local}</Td>
                  <Td><span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><span style={{ fontSize: 15 }}>{r.flag}</span>{r.cur}</span></Td>
                  <Td align="right" mono color="var(--text-primary)">€ {r.eur}</Td>
                  <Td>{r.date}</Td>
                  <Td><DashBadge status={r.status} /></Td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

window.DashboardScreen = DashboardScreen;
window.PvTh = Th; window.PvTd = Td;
