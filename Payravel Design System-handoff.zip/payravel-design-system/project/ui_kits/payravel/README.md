# Payravel — App UI Kit

High-fidelity recreations of the five core Payravel screens, built from the
design-system primitives (no re-implemented Button/Topbar/etc).

## Screens
| File | Screen | Notes |
|------|--------|-------|
| `LoginScreen.jsx` | Login / Registro | Split layout — red brand panel + dark form; toggles login⇄register |
| `DashboardScreen.jsx` | Dashboard do funcionário | Topbar + 4 KPI cards + requests table (click a row → detail) |
| `NewRequestScreen.jsx` | Nova requisição | Lateral stepper + form with live exchange rate → auto EUR |
| `RequestDetailScreen.jsx` | Detalhe da requisição | Big amount + conversion info + history timeline |
| `FinancePanelScreen.jsx` | Painel financeiro (role: finance) | Red user pill, approval queue with inline ✓/✕, critical rows tinted |

## Run it
Open `index.html` — an interactive shell wiring all five screens. Start on Login →
*Entrar* → Dashboard → *Nova requisição* → *Enviar* → row → Detalhe. A bottom
switcher jumps directly to any screen, plus the Financeiro panel.

`data.js` holds shared mock data (`window.PAYRAVEL_DATA`). Each screen script
attaches its component to `window`; `index.html` loads `_ds_bundle.js` first so the
primitives are available as `window.PayravelDesignSystem_6c6388`.

## Starting points
`start-dashboard.html` and `start-finance.html` are single-screen seeds exposed in
the consuming-project Starting Points picker.
