/* Payravel — Detalhe da requisição. Coluna principal (valor + info) + timeline. */
const RD = window.PayravelDesignSystem_6c6388;
const { Topbar: RdTopbar, Badge: RdBadge, Button: RdButton, Card: RdCard } = RD;

function InfoRow({ label, value, mono = true, last = false }) {
  return (
    <div style={{
      display: 'flex', justifyContent: 'space-between', alignItems: 'center',
      padding: '13px 0', borderBottom: last ? 'none' : '0.5px solid var(--border-subtle)',
    }}>
      <span style={{ fontSize: 13, color: 'var(--text-tertiary)' }}>{label}</span>
      <span style={{
        fontSize: 14, color: 'var(--text-primary)',
        fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
        fontVariantNumeric: mono ? 'tabular-nums' : 'normal',
      }}>{value}</span>
    </div>
  );
}

function TimelineItem({ title, time, state, last }) {
  const colors = { done: 'var(--status-approved-fg)', current: 'var(--status-pending-fg)', future: 'var(--text-muted)' };
  const c = colors[state];
  return (
    <div style={{ display: 'flex', gap: 12 }}>
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
        <span style={{
          width: 12, height: 12, borderRadius: 999, flex: 'none', marginTop: 3,
          background: state === 'future' ? 'transparent' : c,
          border: `1.5px solid ${c}`,
        }} />
        {!last && <span style={{ width: '0.5px', flex: 1, minHeight: 32, background: 'var(--border-default)' }} />}
      </div>
      <div style={{ paddingBottom: last ? 0 : 18 }}>
        <div style={{ fontSize: 14, color: state === 'future' ? 'var(--text-tertiary)' : 'var(--text-primary)' }}>{title}</div>
        {time && <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 2, fontFamily: 'var(--font-mono)' }}>{time}</div>}
      </div>
    </div>
  );
}

function RequestDetailScreen({ request, onBack = () => {} }) {
  const r = request || window.PAYRAVEL_DATA.requests[0];
  return (
    <div style={{ minHeight: 600, background: 'var(--bg-base)' }}>
      <RdTopbar
        user={{ name: 'Marina Alves' }}
        nav={[{ label: 'Dashboard' }, { label: 'Requisições', active: true }, { label: 'Histórico' }]}
      />
      <div style={{ padding: 32, maxWidth: 1000, margin: '0 auto' }}>
        <button onClick={onBack} style={{ background: 'none', border: 'none', color: 'var(--text-tertiary)', fontSize: 13, cursor: 'pointer', padding: 0, marginBottom: 18, fontFamily: 'var(--font-sans)' }}>← Voltar para requisições</button>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 320px', gap: 24 }}>
          {/* Main column */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
            <RdCard style={{ padding: 28 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div>
                  <div style={{ fontSize: 13, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', marginBottom: 8 }}>{r.id} · {r.desc}</div>
                  <div style={{ fontSize: 52, fontWeight: 500, fontFamily: 'var(--font-mono)', letterSpacing: '-0.02em', color: 'var(--text-primary)', fontVariantNumeric: 'tabular-nums', lineHeight: 1 }}>
                    € {r.eur}
                  </div>
                  <div style={{ fontSize: 14, color: 'var(--text-tertiary)', marginTop: 10, fontFamily: 'var(--font-mono)' }}>
                    {r.flag} {r.local} {r.cur} · taxa {r.rate}
                  </div>
                </div>
                <RdBadge status={r.status} />
              </div>
            </RdCard>

            <RdCard style={{ padding: '8px 24px 16px' }}>
              <div style={{ fontSize: 13, fontWeight: 500, color: 'var(--text-tertiary)', padding: '16px 0 4px' }}>Informações da conversão</div>
              <InfoRow label="Moeda original" value={`${r.flag} ${r.cur}`} mono={false} />
              <InfoRow label="Valor local" value={`${r.local} ${r.cur}`} />
              <InfoRow label="Equivalente em EUR" value={`€ ${r.eur}`} />
              <InfoRow label="Taxa aplicada" value={r.rate} />
              <InfoRow label="Fonte da taxa" value="ECB · openexchangerates" mono={false} />
              <InfoRow label="Criada em" value={`${r.date} · 09:42`} last />
            </RdCard>
          </div>

          {/* Side column — timeline */}
          <RdCard style={{ padding: 24, height: 'fit-content' }}>
            <div style={{ fontSize: 14, fontWeight: 500, color: 'var(--text-primary)', marginBottom: 20 }}>Histórico</div>
            <TimelineItem title="Requisição criada" time="08 jun · 09:42" state="done" />
            <TimelineItem title="Câmbio capturado (ao vivo)" time="08 jun · 09:42" state="done" />
            <TimelineItem
              title={r.status === 'pending' ? 'Aguardando aprovação' : 'Em revisão pelo financeiro'}
              time={r.status === 'pending' ? 'Agora' : '08 jun · 11:10'}
              state={r.status === 'pending' ? 'current' : 'done'}
            />
            <TimelineItem
              title={r.status === 'approved' ? 'Aprovado · pagamento liberado' : r.status === 'rejected' ? 'Rejeitado pelo financeiro' : r.status === 'expired' ? 'Expirou sem revisão' : 'Resultado da aprovação'}
              time={r.status === 'pending' ? null : '08 jun · 14:25'}
              state={r.status === 'pending' ? 'future' : 'done'}
              last
            />
          </RdCard>
        </div>
      </div>
    </div>
  );
}

window.RequestDetailScreen = RequestDetailScreen;
