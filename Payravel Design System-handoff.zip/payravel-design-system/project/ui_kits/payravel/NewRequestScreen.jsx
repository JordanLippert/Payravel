/* Payravel — Nova requisição de pagamento. Stepper lateral + form com câmbio ao vivo. */
const NR = window.PayravelDesignSystem_6c6388;
const { Topbar: NrTopbar, Stepper: NrStepper, Input: NrInput, Select: NrSelect, Button: NrButton, Badge: NrBadge, Card: NrCard } = NR;

function parseLocal(str) {
  if (!str) return 0;
  const n = String(str).replace(/\./g, '').replace(',', '.').replace(/[^0-9.]/g, '');
  return parseFloat(n) || 0;
}
function fmtEUR(n) {
  return n.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function NewRequestScreen({ onCancel = () => {}, onSubmit = () => {} }) {
  const { currencies } = window.PAYRAVEL_DATA;
  const [desc, setDesc] = React.useState('Licença anual Figma');
  const [amount, setAmount] = React.useState('1.200,00');
  const [cur, setCur] = React.useState('USD');

  const selected = currencies.find((c) => c.value === cur);
  const rate = parseLocal(selected.rate);
  const eur = parseLocal(amount) * rate;

  return (
    <div style={{ minHeight: 600, background: 'var(--bg-base)' }}>
      <NrTopbar
        user={{ name: 'Marina Alves' }}
        nav={[{ label: 'Dashboard' }, { label: 'Requisições', active: true }, { label: 'Histórico' }]}
      />
      <div style={{ padding: 32, maxWidth: 1000, margin: '0 auto' }}>
        <h1 style={{ fontSize: 22, fontWeight: 500, color: 'var(--text-primary)', margin: '0 0 24px' }}>Nova requisição de pagamento</h1>

        <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr', gap: 40 }}>
          {/* Stepper */}
          <div style={{ paddingTop: 8 }}>
            <NrStepper current={1} steps={[
              { title: 'Detalhes', desc: 'Descrição e valor' },
              { title: 'Câmbio', desc: 'Taxa ao vivo' },
              { title: 'Revisão', desc: 'Confirmar e enviar' },
            ]} />
          </div>

          {/* Form */}
          <NrCard style={{ padding: 28 }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 18 }}>
              <NrInput label="Descrição" value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Ex. Licença de software" />

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                <NrInput label="Valor" value={amount} onChange={(e) => setAmount(e.target.value)} mono placeholder="0,00" />
                <NrSelect label="Moeda" value={cur} onChange={setCur} options={currencies} />
              </div>

              <div style={{ height: '0.5px', background: 'var(--border-subtle)', margin: '4px 0' }} />

              <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 }}>
                <NrInput
                  label="Taxa de câmbio" value={selected.rate} readOnly mono
                  suffix={<NrBadge status="approved">ao vivo ✓</NrBadge>}
                />
                <NrInput
                  label="Equivalente em EUR" value={`€ ${fmtEUR(eur)}`} readOnly mono
                  hint="Calculado automaticamente"
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'flex-end', gap: 10, marginTop: 8 }}>
                <NrButton variant="ghost" onClick={onCancel}>Cancelar</NrButton>
                <NrButton variant="primary" onClick={onSubmit}>Enviar para aprovação</NrButton>
              </div>
            </div>
          </NrCard>
        </div>
      </div>
    </div>
  );
}

window.NewRequestScreen = NewRequestScreen;
