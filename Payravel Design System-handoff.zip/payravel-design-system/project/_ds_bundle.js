/* @ds-bundle: {"format":3,"namespace":"PayravelDesignSystem_6c6388","components":[{"name":"Logo","sourcePath":"components/brand/Logo.jsx"},{"name":"Avatar","sourcePath":"components/data-display/Avatar.jsx"},{"name":"Badge","sourcePath":"components/data-display/Badge.jsx"},{"name":"Card","sourcePath":"components/data-display/Card.jsx"},{"name":"MetricCard","sourcePath":"components/data-display/MetricCard.jsx"},{"name":"Button","sourcePath":"components/forms/Button.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"Select","sourcePath":"components/forms/Select.jsx"},{"name":"Pill","sourcePath":"components/navigation/Pill.jsx"},{"name":"Stepper","sourcePath":"components/navigation/Stepper.jsx"},{"name":"Topbar","sourcePath":"components/navigation/Topbar.jsx"}],"sourceHashes":{"components/brand/Logo.jsx":"28167778ba9c","components/data-display/Avatar.jsx":"728e1030a37e","components/data-display/Badge.jsx":"b70c2e090e0c","components/data-display/Card.jsx":"65e36db11d92","components/data-display/MetricCard.jsx":"30fb23941a62","components/forms/Button.jsx":"4da4ca57e2ae","components/forms/Input.jsx":"9e820ae38d6f","components/forms/Select.jsx":"de1e88a957c6","components/navigation/Pill.jsx":"f014bb56d1df","components/navigation/Stepper.jsx":"c1adc518653d","components/navigation/Topbar.jsx":"2bdf998c3c66","ui_kits/payravel-mobile/DetailMobile.jsx":"5dbb5dcd45c3","ui_kits/payravel-mobile/FinanceMobile.jsx":"29ff3cd6889b","ui_kits/payravel-mobile/HomeMobile.jsx":"837901da3270","ui_kits/payravel-mobile/LoginMobile.jsx":"ecc539da3bda","ui_kits/payravel-mobile/NewRequestMobile.jsx":"abdb23238152","ui_kits/payravel-mobile/mobileShell.jsx":"0cccc8dd475d","ui_kits/payravel-mobile/parts.jsx":"2a07ad8e5dda","ui_kits/payravel/DashboardScreen.jsx":"cbefa617312f","ui_kits/payravel/FinancePanelScreen.jsx":"062a65b9e950","ui_kits/payravel/LoginScreen.jsx":"2b22e56712ae","ui_kits/payravel/NewRequestScreen.jsx":"a8206a255627","ui_kits/payravel/RequestDetailScreen.jsx":"dbfee5a1fb74","ui_kits/payravel/data.js":"776d62a16406"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PayravelDesignSystem_6c6388 = window.PayravelDesignSystem_6c6388 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/brand/Logo.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Payravel Logo — the official "moeda-câmbio + ciclo" mark.
 * A split coin (€ filled → $) wrapped by a custom double-arrow conversion ring.
 * Monochrome (vermelho + preto). Renders as mark-only, horizontal lockup, or stacked.
 * The ring can spin (câmbio ao vivo) via `animated`.
 */
function Logo({
  variant = 'lockup',
  // 'mark' | 'lockup' | 'stacked'
  size = 28,
  // mark height in px
  color = 'var(--red-500)',
  // coin + ring color
  knockout = '#000',
  // € cut-out color (sits on the filled half)
  wordmarkColor = 'var(--text-primary)',
  animated = false,
  style = {},
  ...rest
}) {
  const rawId = React.useId();
  const uid = rawId.replace(/[:]/g, '');
  const mark = /*#__PURE__*/React.createElement(LogoMark, {
    size: size,
    color: color,
    knockout: knockout,
    animated: animated,
    uid: uid
  });
  if (variant === 'mark') {
    return /*#__PURE__*/React.createElement("span", _extends({
      style: {
        display: 'inline-flex',
        ...style
      }
    }, rest), mark);
  }
  const stacked = variant === 'stacked';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      flexDirection: stacked ? 'column' : 'row',
      alignItems: 'center',
      gap: stacked ? size * 0.2 : size * 0.16,
      ...style
    }
  }, rest), mark, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-medium)',
      letterSpacing: '-0.03em',
      color: wordmarkColor,
      fontSize: size * 0.62,
      lineHeight: 1
    }
  }, "Payravel"));
}
function LogoMark({
  size,
  color,
  knockout,
  animated,
  uid
}) {
  const r = 17,
    fs = 12;
  const eg = {
    x: 32 - r * 0.32,
    y: 32 - r * 0.32 + fs * 0.36
  };
  const dg = {
    x: 32 + r * 0.36,
    y: 32 + r * 0.36 + fs * 0.36
  };
  const sw = 2.3;
  return /*#__PURE__*/React.createElement("svg", {
    viewBox: "0 0 64 64",
    width: size,
    height: size,
    style: {
      display: 'block',
      overflow: 'visible'
    },
    "aria-label": "Payravel"
  }, /*#__PURE__*/React.createElement("defs", null, /*#__PURE__*/React.createElement("clipPath", {
    id: `ul-${uid}`
  }, /*#__PURE__*/React.createElement("polygon", {
    points: "-4,-4 68,-4 -4,68"
  }))), /*#__PURE__*/React.createElement("g", null, animated && /*#__PURE__*/React.createElement("animateTransform", {
    attributeName: "transform",
    type: "rotate",
    from: "0 32 32",
    to: "360 32 32",
    dur: "5s",
    repeatCount: "indefinite"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M40.2 9.45 A24 24 0 0 1 40.2 54.55",
    fill: "none",
    stroke: color,
    strokeWidth: sw,
    strokeLinecap: "round"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M42.6 49.4 L40.2 54.55 L45.3 57",
    fill: "none",
    stroke: color,
    strokeWidth: sw,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M23.8 54.55 A24 24 0 0 1 23.8 9.45",
    fill: "none",
    stroke: color,
    strokeWidth: sw,
    strokeLinecap: "round"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M21.4 14.6 L23.8 9.45 L18.7 7",
    fill: "none",
    stroke: color,
    strokeWidth: sw,
    strokeLinecap: "round",
    strokeLinejoin: "round"
  })), /*#__PURE__*/React.createElement("circle", {
    cx: "32",
    cy: "32",
    r: r,
    fill: color,
    clipPath: `url(#ul-${uid})`
  }), /*#__PURE__*/React.createElement("text", {
    x: eg.x,
    y: eg.y,
    fontFamily: "var(--font-sans)",
    fontSize: fs,
    fontWeight: "500",
    fill: knockout,
    textAnchor: "middle"
  }, "\u20AC"), /*#__PURE__*/React.createElement("text", {
    x: dg.x,
    y: dg.y,
    fontFamily: "var(--font-sans)",
    fontSize: fs,
    fontWeight: "500",
    fill: color,
    textAnchor: "middle"
  }, "$"));
}
Object.assign(__ds_scope, { Logo });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/brand/Logo.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Avatar.jsx
try { (() => {
/**
 * Payravel Avatar — circular initials chip, solid brand red by default.
 * Used in the topbar user pill and timeline entries.
 */
function Avatar({
  name = '',
  size = 32,
  color = 'var(--red-500)',
  src = null,
  style = {}
}) {
  const initials = name.split(' ').filter(Boolean).slice(0, 2).map(w => w[0]).join('').toUpperCase();
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: size,
      height: size,
      borderRadius: 'var(--radius-full)',
      background: src ? 'transparent' : color,
      color: '#fff',
      overflow: 'hidden',
      fontFamily: 'var(--font-sans)',
      fontWeight: 'var(--weight-medium)',
      fontSize: Math.round(size * 0.4),
      flex: 'none',
      lineHeight: 1,
      ...style
    }
  }, src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : initials);
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Badge.jsx
try { (() => {
const STATUS = {
  pending: {
    fg: 'var(--status-pending-fg)',
    bg: 'var(--status-pending-bg)',
    bd: 'var(--status-pending-border)',
    label: 'Pendente'
  },
  approved: {
    fg: 'var(--status-approved-fg)',
    bg: 'var(--status-approved-bg)',
    bd: 'var(--status-approved-border)',
    label: 'Aprovado'
  },
  rejected: {
    fg: 'var(--status-rejected-fg)',
    bg: 'var(--status-rejected-bg)',
    bd: 'var(--status-rejected-border)',
    label: 'Rejeitado'
  },
  expired: {
    fg: 'var(--status-expired-fg)',
    bg: 'var(--status-expired-bg)',
    bd: 'var(--status-expired-border)',
    label: 'Expirado'
  },
  neutral: {
    fg: 'var(--text-secondary)',
    bg: 'var(--bg-input)',
    bd: 'var(--border-default)',
    label: ''
  }
};

/**
 * Payravel status Badge. Soft tinted fill + matching border + leading dot.
 * Maps the four request states (pendente / aprovado / rejeitado / expirado).
 */
function Badge({
  status = 'neutral',
  children,
  dot = true,
  style = {}
}) {
  const s = STATUS[status] || STATUS.neutral;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      padding: '3px 9px',
      borderRadius: 'var(--radius-sm)',
      fontSize: 12,
      fontWeight: 'var(--weight-medium)',
      lineHeight: 1.4,
      fontFamily: 'var(--font-sans)',
      whiteSpace: 'nowrap',
      color: s.fg,
      background: s.bg,
      border: `0.5px solid ${s.bd}`,
      ...style
    }
  }, dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: 999,
      background: s.fg,
      flex: 'none'
    }
  }), children || s.label);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Badge.jsx", error: String((e && e.message) || e) }); }

// components/data-display/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Payravel Card — flat surface panel. #1a1a1a fill, 8px radius, hairline border,
 * no shadow. The base container for tables, forms, metric groups, detail panes.
 */
function Card({
  padded = true,
  children,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: 'var(--surface-card)',
      border: '0.5px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      padding: padded ? 'var(--pad-card)' : 0,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/Card.jsx", error: String((e && e.message) || e) }); }

// components/data-display/MetricCard.jsx
try { (() => {
/**
 * Payravel MetricCard — the dashboard KPI tile. Label on top, big mono value,
 * optional sublabel/delta and an accent strip for the "highlighted" metric.
 */
function MetricCard({
  label,
  value,
  sub = null,
  accent = false,
  tone = 'default',
  // default | pending | approved | rejected
  style = {}
}) {
  const tones = {
    default: 'var(--text-primary)',
    pending: 'var(--status-pending-fg)',
    approved: 'var(--status-approved-fg)',
    rejected: 'var(--status-rejected-fg)'
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      background: 'var(--surface-card)',
      border: '0.5px solid var(--border-subtle)',
      borderRadius: 'var(--radius-md)',
      padding: '18px 20px',
      display: 'flex',
      flexDirection: 'column',
      gap: 10,
      overflow: 'hidden',
      ...style
    }
  }, accent && /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      bottom: 0,
      width: 2,
      background: 'var(--red-500)'
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--text-tertiary)',
      fontWeight: 'var(--weight-medium)',
      fontFamily: 'var(--font-sans)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontWeight: 'var(--weight-medium)',
      fontSize: 28,
      letterSpacing: '-0.02em',
      color: tones[tone] || tones.default,
      fontVariantNumeric: 'tabular-nums',
      lineHeight: 1
    }
  }, value), sub && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-sans)'
    }
  }, sub));
}
Object.assign(__ds_scope, { MetricCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data-display/MetricCard.jsx", error: String((e && e.message) || e) }); }

// components/forms/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Payravel Button.
 * Flat, no shadow. Primary = solid red; ghost = transparent w/ hairline;
 * danger = solid rejected-red. Hover darkens (primary) or lifts surface (ghost).
 */
function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  fullWidth = false,
  iconLeft = null,
  iconRight = null,
  children,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [active, setActive] = React.useState(false);
  const sizes = {
    sm: {
      padding: '0 12px',
      height: 32,
      fontSize: 13
    },
    md: {
      padding: '0 16px',
      height: 38,
      fontSize: 14
    },
    lg: {
      padding: '0 20px',
      height: 44,
      fontSize: 15
    }
  };
  const palettes = {
    primary: {
      base: {
        background: 'var(--red-500)',
        color: 'var(--on-accent)',
        border: '0.5px solid transparent'
      },
      hover: {
        background: 'var(--red-600)'
      },
      active: {
        background: 'var(--red-700)'
      }
    },
    ghost: {
      base: {
        background: 'transparent',
        color: 'var(--text-primary)',
        border: '0.5px solid var(--border-default)'
      },
      hover: {
        background: 'var(--bg-input-hover)',
        border: '0.5px solid var(--border-strong)'
      },
      active: {
        background: 'var(--bg-input)'
      }
    },
    danger: {
      base: {
        background: 'var(--status-rejected-fg)',
        color: '#fff',
        border: '0.5px solid transparent'
      },
      hover: {
        background: '#d83a3a'
      },
      active: {
        background: '#c23030'
      }
    }
  };
  const p = palettes[variant] || palettes.primary;
  const s = sizes[size] || sizes.md;
  const styleObj = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: s.height,
    padding: s.padding,
    width: fullWidth ? '100%' : 'auto',
    fontFamily: 'var(--font-sans)',
    fontSize: s.fontSize,
    fontWeight: 'var(--weight-medium)',
    lineHeight: 1,
    borderRadius: 'var(--radius-sm)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.4 : 1,
    transition: 'background 120ms ease, border-color 120ms ease',
    whiteSpace: 'nowrap',
    ...p.base,
    ...(!disabled && hover ? p.hover : {}),
    ...(!disabled && active ? p.active : {}),
    ...style
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    style: styleObj,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => {
      setHover(false);
      setActive(false);
    },
    onMouseDown: () => setActive(true),
    onMouseUp: () => setActive(false)
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Button.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Payravel text input. Faint translucent fill, hairline border that warms to
 * soft red on hover/focus. Supports label, readonly state, and a trailing
 * adornment (e.g. a "ao vivo ✓" badge or a EUR suffix).
 */
function Input({
  label = null,
  hint = null,
  value,
  placeholder = '',
  readOnly = false,
  disabled = false,
  type = 'text',
  prefix = null,
  suffix = null,
  mono = false,
  style = {},
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const [focus, setFocus] = React.useState(false);
  const borderColor = focus || hover ? 'var(--red-border)' : 'var(--border-default)';
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-tertiary)',
      fontFamily: 'var(--font-sans)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      background: readOnly ? 'rgba(255,255,255,0.02)' : 'var(--bg-input)',
      border: `0.5px solid ${readOnly ? 'var(--border-default)' : borderColor}`,
      borderRadius: 'var(--radius-sm)',
      padding: '0 12px',
      height: 38,
      opacity: disabled ? 0.4 : 1,
      transition: 'border-color 120ms ease'
    },
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false)
  }, prefix && /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--text-tertiary)',
      fontSize: 14,
      display: 'inline-flex'
    }
  }, prefix), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    value: value,
    placeholder: placeholder,
    readOnly: readOnly,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      background: 'transparent',
      border: 'none',
      outline: 'none',
      color: 'var(--text-primary)',
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
      fontSize: 14,
      fontWeight: 'var(--weight-regular)',
      fontVariantNumeric: mono ? 'tabular-nums' : 'normal'
    }
  }, rest)), suffix && /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      flex: 'none'
    }
  }, suffix)), hint && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-sans)'
    }
  }, hint));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/forms/Select.jsx
try { (() => {
/**
 * Payravel Select — a styled dropdown. Used for the currency picker, where each
 * option carries a flag glyph + code. Controlled via `value`/`onChange`(value).
 * Lightweight custom popover so we can render flags; not a native <select>.
 */
function Select({
  label = null,
  value,
  onChange = () => {},
  options = [],
  placeholder = 'Selecionar',
  disabled = false,
  style = {}
}) {
  const [open, setOpen] = React.useState(false);
  const [hover, setHover] = React.useState(false);
  const ref = React.useRef(null);
  React.useEffect(() => {
    function onDoc(e) {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    }
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, []);
  const selected = options.find(o => o.value === value);
  const borderColor = open || hover ? 'var(--red-border)' : 'var(--border-default)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      ...style
    },
    ref: ref
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 'var(--weight-medium)',
      color: 'var(--text-tertiary)',
      fontFamily: 'var(--font-sans)'
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement("button", {
    type: "button",
    disabled: disabled,
    onClick: () => setOpen(o => !o),
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      height: 38,
      padding: '0 12px',
      background: 'var(--bg-input)',
      border: `0.5px solid ${borderColor}`,
      borderRadius: 'var(--radius-sm)',
      cursor: disabled ? 'not-allowed' : 'pointer',
      color: selected ? 'var(--text-primary)' : 'var(--text-muted)',
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      transition: 'border-color 120ms ease',
      opacity: disabled ? 0.4 : 1
    }
  }, selected ? /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8
    }
  }, selected.flag && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 16,
      lineHeight: 1
    }
  }, selected.flag), /*#__PURE__*/React.createElement("span", null, selected.label)) : placeholder, /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      color: 'var(--text-muted)',
      transform: open ? 'rotate(180deg)' : 'none',
      transition: 'transform 120ms ease'
    }
  }, "\u25BE")), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 'calc(100% + 4px)',
      left: 0,
      right: 0,
      zIndex: 20,
      background: 'var(--bg-elevated)',
      border: '0.5px solid var(--border-default)',
      borderRadius: 'var(--radius-md)',
      boxShadow: 'var(--shadow-menu)',
      padding: 4,
      maxHeight: 240,
      overflowY: 'auto'
    }
  }, options.map(o => {
    const isSel = o.value === value;
    return /*#__PURE__*/React.createElement("div", {
      key: o.value,
      onClick: () => {
        onChange(o.value);
        setOpen(false);
      },
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 8,
        padding: '8px 10px',
        borderRadius: 'var(--radius-sm)',
        cursor: 'pointer',
        color: 'var(--text-primary)',
        fontFamily: 'var(--font-sans)',
        fontSize: 14,
        background: isSel ? 'var(--bg-input-hover)' : 'transparent'
      },
      onMouseEnter: e => {
        e.currentTarget.style.background = 'var(--bg-input-hover)';
      },
      onMouseLeave: e => {
        e.currentTarget.style.background = isSel ? 'var(--bg-input-hover)' : 'transparent';
      }
    }, o.flag && /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 16,
        lineHeight: 1
      }
    }, o.flag), /*#__PURE__*/React.createElement("span", null, o.label), o.meta && /*#__PURE__*/React.createElement("span", {
      style: {
        marginLeft: 'auto',
        color: 'var(--text-muted)',
        fontSize: 12,
        fontFamily: 'var(--font-mono)'
      }
    }, o.meta));
  }))));
}
Object.assign(__ds_scope, { Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Select.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Pill.jsx
try { (() => {
/**
 * Payravel user Pill — avatar + name in a rounded capsule. When `role` is set
 * (e.g. "Finance"), the whole pill turns solid red to flag elevated access.
 */
function Pill({
  name = '',
  role = null,
  style = {}
}) {
  const isElevated = !!role;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      padding: '4px 12px 4px 4px',
      borderRadius: 'var(--radius-full)',
      background: isElevated ? 'var(--red-500)' : 'var(--bg-input)',
      border: `0.5px solid ${isElevated ? 'transparent' : 'var(--border-default)'}`,
      fontFamily: 'var(--font-sans)',
      cursor: 'default',
      ...style
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Avatar, {
    name: name,
    size: 26,
    color: isElevated ? 'rgba(0,0,0,0.25)' : 'var(--red-500)'
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      lineHeight: 1.2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 'var(--weight-medium)',
      color: isElevated ? '#fff' : 'var(--text-primary)'
    }
  }, name), role && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      color: 'rgba(255,255,255,0.8)'
    }
  }, role)));
}
Object.assign(__ds_scope, { Pill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Pill.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Stepper.jsx
try { (() => {
/**
 * Payravel Stepper — vertical progress rail for the new-request flow
 * (Detalhes → Câmbio → Revisão). Past steps red-filled with check, current
 * step ringed red, future steps muted.
 */
function Stepper({
  steps = [],
  current = 0,
  style = {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 0,
      ...style
    }
  }, steps.map((step, i) => {
    const done = i < current;
    const active = i === current;
    const last = i === steps.length - 1;
    const title = typeof step === 'string' ? step : step.title;
    const desc = typeof step === 'string' ? null : step.desc;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 12,
        position: 'relative'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 26,
        height: 26,
        borderRadius: 999,
        flex: 'none',
        display: 'inline-flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontFamily: 'var(--font-sans)',
        fontSize: 12,
        fontWeight: 'var(--weight-medium)',
        background: done ? 'var(--red-500)' : 'transparent',
        color: done ? '#fff' : active ? 'var(--red-500)' : 'var(--text-muted)',
        border: `0.5px solid ${done ? 'var(--red-500)' : active ? 'var(--red-border)' : 'var(--border-default)'}`
      }
    }, done ? '✓' : i + 1), !last && /*#__PURE__*/React.createElement("span", {
      style: {
        width: '0.5px',
        flex: 1,
        minHeight: 28,
        background: done ? 'var(--red-border)' : 'var(--border-default)'
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        paddingBottom: last ? 0 : 22,
        paddingTop: 3
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14,
        fontFamily: 'var(--font-sans)',
        fontWeight: active ? 'var(--weight-medium)' : 'var(--weight-regular)',
        color: active || done ? 'var(--text-primary)' : 'var(--text-tertiary)'
      }
    }, title), desc && /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: 'var(--text-muted)',
        marginTop: 2,
        fontFamily: 'var(--font-sans)'
      }
    }, desc)));
  }));
}
Object.assign(__ds_scope, { Stepper });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Stepper.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Topbar.jsx
try { (() => {
/**
 * Payravel Topbar — #1a1a1a bar with the moeda-câmbio logo, nav links, and a
 * user Pill at the right. Nav items: { label, active }. The logo ring spins on
 * hover (câmbio ao vivo).
 */
function Topbar({
  nav = [],
  user = {
    name: '',
    role: null
  },
  onNav = () => {},
  style = {}
}) {
  const [logoHover, setLogoHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("header", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 32,
      height: 60,
      padding: '0 24px',
      background: 'var(--bg-surface)',
      borderBottom: '0.5px solid var(--border-subtle)',
      fontFamily: 'var(--font-sans)',
      ...style
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      cursor: 'pointer'
    },
    onMouseEnter: () => setLogoHover(true),
    onMouseLeave: () => setLogoHover(false)
  }, /*#__PURE__*/React.createElement(__ds_scope.Logo, {
    size: 44,
    animated: logoHover
  })), /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 4
    }
  }, nav.map((item, i) => /*#__PURE__*/React.createElement("button", {
    key: i,
    type: "button",
    onClick: () => onNav(item),
    style: {
      background: 'transparent',
      border: 'none',
      cursor: 'pointer',
      padding: '6px 12px',
      borderRadius: 'var(--radius-sm)',
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      fontWeight: item.active ? 'var(--weight-medium)' : 'var(--weight-regular)',
      color: item.active ? 'var(--text-primary)' : 'var(--text-tertiary)',
      transition: 'color 120ms ease, background 120ms ease'
    },
    onMouseEnter: e => {
      if (!item.active) e.currentTarget.style.color = 'var(--text-secondary)';
    },
    onMouseLeave: e => {
      if (!item.active) e.currentTarget.style.color = 'var(--text-tertiary)';
    }
  }, item.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginLeft: 'auto'
    }
  }, /*#__PURE__*/React.createElement(__ds_scope.Pill, {
    name: user.name,
    role: user.role
  })));
}
Object.assign(__ds_scope, { Topbar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Topbar.jsx", error: String((e && e.message) || e) }); }

// ui_kits/payravel-mobile/DetailMobile.jsx
try { (() => {
/* Payravel Mobile — Detalhe da requisição. Amount hero + info + timeline. */

function DetailMobile({
  request,
  onBack = () => {}
}) {
  const r = request || window.PAYRAVEL_DATA.requests[0];
  const s = (window.PV_STATUS_M || {})[r.status] || {};
  const timeline = [{
    label: 'Requisição criada',
    time: `${r.date} · 14:32`,
    done: true
  }, {
    label: 'Enviada para aprovação',
    time: `${r.date} · 14:32`,
    done: true
  }, r.status === 'approved' ? {
    label: 'Aprovada por Financeiro',
    time: '09 jun · 10:05',
    tone: 'approved'
  } : r.status === 'rejected' ? {
    label: 'Rejeitada por Financeiro',
    time: '09 jun · 11:20',
    tone: 'rejected'
  } : r.status === 'expired' ? {
    label: 'Expirada sem revisão',
    time: '08 jun · 23:59',
    tone: 'expired'
  } : {
    label: 'Aguardando revisão',
    time: 'Prazo: 24h',
    tone: 'pending',
    pending: true
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '6px 16px 0',
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      height: 46
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      background: 'var(--bg-input)',
      border: '0.5px solid var(--border-default)',
      borderRadius: 11,
      width: 38,
      height: 38,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(PvIcon, {
    name: "chevronLeft",
    size: 20,
    color: "var(--text-primary)"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--text-tertiary)',
      fontFamily: 'var(--font-mono)'
    }
  }, r.id)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '14px 20px 28px',
      display: 'flex',
      flexDirection: 'column',
      gap: 22
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 56,
      height: 56,
      borderRadius: 18,
      background: 'var(--bg-input)',
      border: '0.5px solid var(--border-default)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 28
    }
  }, r.flag), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'var(--text-tertiary)'
    }
  }, r.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 46,
      fontWeight: 500,
      letterSpacing: '-0.02em',
      color: 'var(--text-primary)',
      marginTop: 6,
      lineHeight: 1.05
    }
  }, "\u20AC ", r.eur), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 14,
      color: 'var(--text-muted)',
      marginTop: 4
    }
  }, r.cur, " ", r.local)), /*#__PURE__*/React.createElement(PvStatusChip, {
    status: r.status
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      border: '0.5px solid var(--border-subtle)',
      borderRadius: 16,
      overflow: 'hidden'
    }
  }, [['Moeda original', `${r.flag} ${r.cur}`], ['Valor local', `${r.cur} ${r.local}`], ['Equivalente em EUR', `€ ${r.eur}`], ['Taxa de câmbio', r.rate], ['Fonte da taxa', 'ECB · ao vivo'], ['Solicitante', r.employee]].map(([k, v], i, a) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      padding: '14px 16px',
      borderBottom: i < a.length - 1 ? '0.5px solid var(--border-subtle)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13.5,
      color: 'var(--text-tertiary)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13.5,
      color: 'var(--text-primary)',
      fontWeight: 500,
      fontFamily: k.includes('Taxa') || k.includes('EUR') || k.includes('Valor') ? 'var(--font-mono)' : 'var(--font-sans)',
      textAlign: 'right'
    }
  }, v)))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: 'var(--text-primary)',
      marginBottom: 14
    }
  }, "Hist\xF3rico"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column'
    }
  }, timeline.map((t, i, a) => {
    const c = t.tone ? `var(--status-${t.tone}-fg)` : 'var(--red-500)';
    const last = i === a.length - 1;
    return /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        display: 'flex',
        gap: 14
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 22,
        height: 22,
        borderRadius: 999,
        flex: 'none',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        background: t.pending ? 'transparent' : c,
        border: `1.5px solid ${c}`
      }
    }, !t.pending && /*#__PURE__*/React.createElement(PvIcon, {
      name: t.tone === 'rejected' ? 'x' : 'check',
      size: 12,
      color: "#fff",
      strokeWidth: 2.6
    })), !last && /*#__PURE__*/React.createElement("span", {
      style: {
        width: '1.5px',
        flex: 1,
        minHeight: 30,
        background: 'var(--border-default)'
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        paddingBottom: last ? 0 : 20,
        marginTop: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14,
        color: 'var(--text-primary)',
        fontWeight: t.tone ? 500 : 400
      }
    }, t.label), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: 'var(--text-muted)',
        marginTop: 2
      }
    }, t.time)));
  })))));
}
window.DetailMobile = DetailMobile;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/payravel-mobile/DetailMobile.jsx", error: String((e && e.message) || e) }); }

// ui_kits/payravel-mobile/FinanceMobile.jsx
try { (() => {
/* Payravel Mobile — Painel financeiro (role: finance). */

function FinanceMobile({
  onOpen = () => {}
}) {
  const {
    financeQueue
  } = window.PAYRAVEL_DATA;
  const [done, setDone] = React.useState({}); // id -> 'approved' | 'rejected'

  const metrics = [{
    label: 'Aguardando revisão',
    value: '4',
    tone: 'var(--status-pending-fg)'
  }, {
    label: 'Total em EUR',
    value: '€ 2.758',
    tone: 'var(--text-primary)'
  }, {
    label: 'Aprovados hoje',
    value: '7',
    tone: 'var(--status-approved-fg)'
  }, {
    label: 'Expiram em 24h',
    value: '2',
    tone: 'var(--status-rejected-fg)'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '8px 18px 28px',
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-tertiary)'
    }
  }, "Painel"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 500,
      color: 'var(--text-primary)',
      marginTop: 2
    }
  }, "Aprova\xE7\xF5es")), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      padding: '5px 12px 5px 5px',
      borderRadius: 999,
      background: 'var(--red-500)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 26,
      height: 26,
      borderRadius: 999,
      background: 'rgba(0,0,0,0.25)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement(PvIcon, {
    name: "shield",
    size: 15,
    color: "#fff"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      lineHeight: 1.15
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12.5,
      fontWeight: 500,
      color: '#fff'
    }
  }, "Lucas Costa"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10.5,
      color: 'rgba(255,255,255,0.82)'
    }
  }, "Finance")))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 10
    }
  }, metrics.map(m => /*#__PURE__*/React.createElement("div", {
    key: m.label,
    style: {
      background: 'var(--surface-card)',
      border: '0.5px solid var(--border-subtle)',
      borderRadius: 14,
      padding: '14px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 22,
      fontWeight: 500,
      color: m.tone,
      lineHeight: 1
    }
  }, m.value), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-tertiary)',
      marginTop: 7
    }
  }, m.label)))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 500,
      color: 'var(--text-primary)'
    }
  }, "Fila de revis\xE3o"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, financeQueue.map(q => {
    const resolved = done[q.id];
    const critical = q.critical && !resolved;
    const critColor = q.expires.includes('h') ? 'var(--status-rejected-fg)' : 'var(--status-pending-fg)';
    return /*#__PURE__*/React.createElement("div", {
      key: q.id,
      style: {
        background: 'var(--surface-card)',
        border: `0.5px solid ${critical ? critColor : 'var(--border-subtle)'}`,
        borderRadius: 16,
        padding: 16,
        display: 'flex',
        flexDirection: 'column',
        gap: 14,
        opacity: resolved ? 0.55 : 1,
        transition: 'opacity 200ms ease'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'center',
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 40,
        height: 40,
        borderRadius: 12,
        flex: 'none',
        background: 'var(--bg-input)',
        border: '0.5px solid var(--border-default)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        fontSize: 20
      }
    }, q.flag), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14.5,
        fontWeight: 500,
        color: 'var(--text-primary)',
        overflow: 'hidden',
        textOverflow: 'ellipsis',
        whiteSpace: 'nowrap'
      }
    }, q.desc), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: 'var(--text-muted)',
        marginTop: 2
      }
    }, q.employee)), /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 4,
        fontSize: 11.5,
        fontWeight: 500,
        color: critical ? critColor : 'var(--text-muted)',
        background: critical ? 'color-mix(in srgb, ' + critColor + ' 12%, transparent)' : 'var(--bg-input)',
        border: `0.5px solid ${critical ? critColor : 'var(--border-default)'}`,
        borderRadius: 999,
        padding: '3px 8px'
      }
    }, /*#__PURE__*/React.createElement(PvIcon, {
      name: "clock",
      size: 12,
      color: critical ? critColor : 'var(--text-muted)'
    }), q.expires)), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        alignItems: 'flex-end',
        justifyContent: 'space-between'
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11.5,
        color: 'var(--text-muted)'
      }
    }, q.cur, " ", q.local), /*#__PURE__*/React.createElement("div", {
      style: {
        fontFamily: 'var(--font-mono)',
        fontSize: 19,
        fontWeight: 500,
        color: 'var(--text-primary)',
        marginTop: 2
      }
    }, "\u20AC ", q.eur)), resolved ? /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6,
        fontSize: 13,
        fontWeight: 500,
        color: `var(--status-${resolved}-fg)`
      }
    }, /*#__PURE__*/React.createElement(PvIcon, {
      name: resolved === 'approved' ? 'check' : 'x',
      size: 16,
      color: `var(--status-${resolved}-fg)`,
      strokeWidth: 2.4
    }), resolved === 'approved' ? 'Aprovado' : 'Rejeitado') : /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => setDone({
        ...done,
        [q.id]: 'rejected'
      }),
      style: {
        width: 42,
        height: 42,
        borderRadius: 12,
        cursor: 'pointer',
        background: 'var(--status-rejected-bg)',
        border: '0.5px solid var(--status-rejected-border)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement(PvIcon, {
      name: "x",
      size: 18,
      color: "var(--status-rejected-fg)",
      strokeWidth: 2.2
    })), /*#__PURE__*/React.createElement("button", {
      onClick: () => setDone({
        ...done,
        [q.id]: 'approved'
      }),
      style: {
        width: 42,
        height: 42,
        borderRadius: 12,
        cursor: 'pointer',
        background: 'var(--status-approved-bg)',
        border: '0.5px solid var(--status-approved-border)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center'
      }
    }, /*#__PURE__*/React.createElement(PvIcon, {
      name: "check",
      size: 18,
      color: "var(--status-approved-fg)",
      strokeWidth: 2.2
    })))));
  })));
}
window.FinanceMobile = FinanceMobile;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/payravel-mobile/FinanceMobile.jsx", error: String((e && e.message) || e) }); }

// ui_kits/payravel-mobile/HomeMobile.jsx
try { (() => {
/* Payravel Mobile — Home (dashboard do funcionário). */
const PvNS_home = window.PayravelDesignSystem_6c6388 || {};
const {
  Avatar: PvAvatarH
} = PvNS_home;
function HomeMobile({
  onOpen = () => {},
  onNew = () => {}
}) {
  const {
    requests
  } = window.PAYRAVEL_DATA;
  const [filter, setFilter] = React.useState('all');
  const filters = [['all', 'Todas'], ['pending', 'Pendente'], ['approved', 'Aprovado'], ['rejected', 'Rejeitado']];
  const list = filter === 'all' ? requests : requests.filter(r => r.status === filter);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20,
      padding: '8px 18px 28px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-tertiary)'
    }
  }, "Bem-vinda de volta,"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 500,
      color: 'var(--text-primary)',
      marginTop: 2
    }
  }, "Marina Alves")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("button", {
    style: {
      background: 'var(--bg-input)',
      border: '0.5px solid var(--border-default)',
      borderRadius: 12,
      width: 40,
      height: 40,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer',
      position: 'relative'
    }
  }, /*#__PURE__*/React.createElement(PvIcon, {
    name: "bell",
    size: 20,
    color: "var(--text-secondary)"
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      top: 9,
      right: 10,
      width: 7,
      height: 7,
      borderRadius: 999,
      background: 'var(--red-500)',
      border: '1.5px solid var(--bg-base)'
    }
  })), /*#__PURE__*/React.createElement(PvAvatarH, {
    name: "Marina Alves",
    size: 40
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      border: '0.5px solid var(--border-subtle)',
      borderRadius: 20,
      padding: 22,
      position: 'relative',
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: 'absolute',
      left: 0,
      top: 0,
      bottom: 0,
      width: 3,
      background: 'var(--red-500)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--text-tertiary)'
    }
  }, "Total enviado em junho"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 4,
      fontSize: 12,
      color: 'var(--status-approved-fg)'
    }
  }, /*#__PURE__*/React.createElement(PvIcon, {
    name: "arrowUpRight",
    size: 14,
    color: "var(--status-approved-fg)"
  }), "12%")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 40,
      fontWeight: 500,
      letterSpacing: '-0.02em',
      color: 'var(--text-primary)',
      fontVariantNumeric: 'tabular-nums',
      marginTop: 10
    }
  }, "\u20AC 3.408", /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 22,
      color: 'var(--text-tertiary)'
    }
  }, ",40")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: 'var(--text-muted)',
      marginTop: 6
    }
  }, "convertido de 4 moedas \xB7 5 requisi\xE7\xF5es")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, [['Pendente', '1', 'var(--status-pending-fg)'], ['Aprovado', '2', 'var(--status-approved-fg)'], ['Rejeitado', '1', 'var(--status-rejected-fg)']].map(([l, v, c]) => /*#__PURE__*/React.createElement("div", {
    key: l,
    style: {
      flex: 1,
      background: 'var(--surface-card)',
      border: '0.5px solid var(--border-subtle)',
      borderRadius: 14,
      padding: '13px 14px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 22,
      fontWeight: 500,
      color: c,
      lineHeight: 1
    }
  }, v), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-tertiary)',
      marginTop: 7
    }
  }, l)))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginTop: 2
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 500,
      color: 'var(--text-primary)'
    }
  }, "Requisi\xE7\xF5es recentes")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      overflowX: 'auto',
      margin: '-4px -18px 0',
      padding: '4px 18px'
    }
  }, filters.map(([id, lbl]) => /*#__PURE__*/React.createElement("button", {
    key: id,
    onClick: () => setFilter(id),
    style: {
      flex: 'none',
      padding: '7px 14px',
      borderRadius: 999,
      cursor: 'pointer',
      fontFamily: 'var(--font-sans)',
      fontSize: 13,
      fontWeight: 500,
      whiteSpace: 'nowrap',
      background: filter === id ? 'var(--text-primary)' : 'var(--bg-input)',
      color: filter === id ? '#000' : 'var(--text-tertiary)',
      border: `0.5px solid ${filter === id ? 'transparent' : 'var(--border-default)'}`
    }
  }, lbl))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 12
    }
  }, list.map(r => /*#__PURE__*/React.createElement(PvRequestCard, {
    key: r.id,
    req: r,
    onClick: () => onOpen(r)
  })), list.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      color: 'var(--text-muted)',
      fontSize: 13,
      padding: '24px 0'
    }
  }, "Nenhuma requisi\xE7\xE3o neste filtro.")));
}
window.HomeMobile = HomeMobile;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/payravel-mobile/HomeMobile.jsx", error: String((e && e.message) || e) }); }

// ui_kits/payravel-mobile/LoginMobile.jsx
try { (() => {
/* Payravel Mobile — Login / Registro. Red hero + dark sheet. */
const PvNS_login = window.PayravelDesignSystem_6c6388 || {};
const {
  Logo: PvLogoM,
  Button: PvBtnM,
  Input: PvInputM
} = PvNS_login;
function LoginMobile({
  onLogin = () => {}
}) {
  const [mode, setMode] = React.useState('login');
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%',
      display: 'flex',
      flexDirection: 'column',
      background: 'var(--red-500)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '36px 28px 60px',
      display: 'flex',
      flexDirection: 'column',
      gap: 28,
      color: '#fff'
    }
  }, /*#__PURE__*/React.createElement(PvLogoM, {
    size: 40,
    color: "#fff",
    knockout: "#CC0000",
    wordmarkColor: "#fff"
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 32,
      fontWeight: 500,
      lineHeight: 1.12,
      letterSpacing: '-0.02em',
      margin: 0
    }
  }, "Pagamentos", /*#__PURE__*/React.createElement("br", null), "multi-moeda,", /*#__PURE__*/React.createElement("br", null), "sem fronteiras."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      lineHeight: 1.5,
      color: 'rgba(255,255,255,0.85)',
      marginTop: 14,
      maxWidth: 300
    }
  }, "Solicite, converta e acompanhe reembolsos \u2014 c\xE2mbio ao vivo, tudo em EUR."))), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      background: 'var(--bg-base)',
      borderTopLeftRadius: 28,
      borderTopRightRadius: 28,
      marginTop: -24,
      padding: '30px 26px 36px',
      display: 'flex',
      flexDirection: 'column',
      gap: 22,
      borderTop: '0.5px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      background: 'var(--bg-input)',
      borderRadius: 12,
      padding: 4
    }
  }, [['login', 'Entrar'], ['register', 'Registrar']].map(([id, lbl]) => /*#__PURE__*/React.createElement("button", {
    key: id,
    onClick: () => setMode(id),
    style: {
      flex: 1,
      padding: '10px 0',
      borderRadius: 9,
      border: 'none',
      cursor: 'pointer',
      background: mode === id ? 'var(--bg-elevated)' : 'transparent',
      color: mode === id ? 'var(--text-primary)' : 'var(--text-tertiary)',
      fontFamily: 'var(--font-sans)',
      fontSize: 14,
      fontWeight: 500,
      boxShadow: mode === id ? '0 1px 0 rgba(255,255,255,0.04)' : 'none'
    }
  }, lbl))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, mode === 'register' && /*#__PURE__*/React.createElement(PvInputM, {
    label: "Nome completo",
    placeholder: "Marina Alves"
  }), /*#__PURE__*/React.createElement(PvInputM, {
    label: "E-mail",
    type: "email",
    defaultValue: "marina@empresa.com",
    placeholder: "voce@empresa.com"
  }), /*#__PURE__*/React.createElement(PvInputM, {
    label: "Senha",
    type: "password",
    defaultValue: "123456",
    placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"
  })), /*#__PURE__*/React.createElement(PvBtnM, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    onClick: onLogin
  }, mode === 'login' ? 'Entrar' : 'Criar conta'), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      textAlign: 'center',
      marginTop: 'auto'
    }
  }, mode === 'login' ? 'Esqueceu a senha? ' : 'Já tem conta? ', /*#__PURE__*/React.createElement("span", {
    onClick: () => setMode(mode === 'login' ? 'register' : 'login'),
    style: {
      color: 'var(--text-secondary)',
      borderBottom: '0.5px solid var(--border-strong)'
    }
  }, mode === 'login' ? 'Recuperar acesso' : 'Entrar'))));
}
window.LoginMobile = LoginMobile;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/payravel-mobile/LoginMobile.jsx", error: String((e && e.message) || e) }); }

// ui_kits/payravel-mobile/NewRequestMobile.jsx
try { (() => {
/* Payravel Mobile — Nova requisição (fluxo 3 passos + câmbio ao vivo). */
const PvNS_new = window.PayravelDesignSystem_6c6388 || {};
const {
  Input: PvInputN,
  Button: PvBtnN
} = PvNS_new;
function TopBarFlow({
  title,
  onBack,
  step,
  total
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      top: 0,
      zIndex: 5,
      background: 'var(--bg-base)',
      padding: '6px 16px 14px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      height: 40
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      background: 'var(--bg-input)',
      border: '0.5px solid var(--border-default)',
      borderRadius: 11,
      width: 38,
      height: 38,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement(PvIcon, {
    name: "chevronLeft",
    size: 20,
    color: "var(--text-primary)"
  })), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 16,
      fontWeight: 500,
      color: 'var(--text-primary)'
    }
  }, title), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontSize: 12.5,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)'
    }
  }, step, "/", total)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      marginTop: 12
    }
  }, Array.from({
    length: total
  }).map((_, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      flex: 1,
      height: 3,
      borderRadius: 999,
      background: i < step ? 'var(--red-500)' : 'var(--border-default)',
      transition: 'background 200ms ease'
    }
  }))));
}
function CurrencySheet({
  value,
  onPick
}) {
  const {
    currencies
  } = window.PAYRAVEL_DATA;
  const [open, setOpen] = React.useState(false);
  const sel = currencies.find(c => c.value === value) || currencies[0];
  return /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 500,
      color: 'var(--text-tertiary)'
    }
  }, "Moeda"), /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(!open),
    style: {
      width: '100%',
      marginTop: 6,
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      cursor: 'pointer',
      height: 48,
      padding: '0 14px',
      background: 'var(--bg-input)',
      border: `0.5px solid ${open ? 'var(--red-border)' : 'var(--border-default)'}`,
      borderRadius: 12,
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 22
    }
  }, sel.flag), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      color: 'var(--text-primary)'
    }
  }, sel.label), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      color: 'var(--text-muted)'
    }
  }, sel.meta), /*#__PURE__*/React.createElement(PvIcon, {
    name: "chevronDown",
    size: 18,
    color: "var(--text-muted)"
  })), open && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      background: 'var(--bg-elevated)',
      border: '0.5px solid var(--border-default)',
      borderRadius: 12,
      overflow: 'hidden'
    }
  }, currencies.map(c => /*#__PURE__*/React.createElement("button", {
    key: c.value,
    onClick: () => {
      onPick(c.value);
      setOpen(false);
    },
    style: {
      width: '100%',
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      padding: '12px 14px',
      cursor: 'pointer',
      background: c.value === value ? 'var(--bg-input-hover)' : 'transparent',
      border: 'none',
      borderBottom: '0.5px solid var(--border-subtle)',
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 20
    }
  }, c.flag), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14.5,
      color: 'var(--text-primary)'
    }
  }, c.label), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: 'auto',
      fontFamily: 'var(--font-mono)',
      fontSize: 12.5,
      color: 'var(--text-muted)'
    }
  }, c.meta)))));
}
function NewRequestMobile({
  onCancel = () => {},
  onSubmit = () => {}
}) {
  const {
    currencies
  } = window.PAYRAVEL_DATA;
  const [step, setStep] = React.useState(1);
  const [desc, setDesc] = React.useState('Licença anual Figma');
  const [amount, setAmount] = React.useState('1.200,00');
  const [cur, setCur] = React.useState('USD');
  const rate = (currencies.find(c => c.value === cur) || {}).rate || '0,9200';
  const eur = '1.104,00';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: '100%',
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement(TopBarFlow, {
    title: "Nova requisi\xE7\xE3o",
    onBack: step === 1 ? onCancel : () => setStep(step - 1),
    step: step,
    total: 3
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      padding: '8px 18px 20px',
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, step === 1 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 500,
      color: 'var(--text-primary)'
    }
  }, "Detalhes"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-tertiary)',
      marginTop: 3
    }
  }, "O que voc\xEA precisa reembolsar?")), /*#__PURE__*/React.createElement(PvInputN, {
    label: "Descri\xE7\xE3o",
    value: desc,
    onChange: e => setDesc(e.target.value)
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 500,
      color: 'var(--text-tertiary)'
    }
  }, "Valor"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 6,
      display: 'flex',
      alignItems: 'center',
      gap: 10,
      height: 56,
      padding: '0 16px',
      background: 'var(--bg-input)',
      border: '0.5px solid var(--border-default)',
      borderRadius: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 18,
      color: 'var(--text-muted)'
    }
  }, cur), /*#__PURE__*/React.createElement("input", {
    value: amount,
    onChange: e => setAmount(e.target.value),
    style: {
      flex: 1,
      minWidth: 0,
      background: 'none',
      border: 'none',
      outline: 'none',
      textAlign: 'right',
      fontFamily: 'var(--font-mono)',
      fontSize: 26,
      fontWeight: 500,
      color: 'var(--text-primary)',
      fontVariantNumeric: 'tabular-nums'
    }
  }))), /*#__PURE__*/React.createElement(CurrencySheet, {
    value: cur,
    onPick: setCur
  })), step === 2 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 500,
      color: 'var(--text-primary)'
    }
  }, "C\xE2mbio"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-tertiary)',
      marginTop: 3
    }
  }, "Taxa buscada automaticamente.")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      border: '0.5px solid var(--border-subtle)',
      borderRadius: 16,
      padding: 18,
      display: 'flex',
      flexDirection: 'column',
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--text-tertiary)'
    }
  }, "Taxa de c\xE2mbio"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      fontSize: 11.5,
      fontWeight: 500,
      color: 'var(--status-approved-fg)',
      background: 'var(--status-approved-bg)',
      border: '0.5px solid var(--status-approved-border)',
      borderRadius: 999,
      padding: '3px 9px'
    }
  }, /*#__PURE__*/React.createElement(PvIcon, {
    name: "zap",
    size: 12,
    color: "var(--status-approved-fg)",
    fill: "var(--status-approved-fg)"
  }), "ao vivo")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 30,
      fontWeight: 500,
      color: 'var(--text-primary)',
      fontVariantNumeric: 'tabular-nums'
    }
  }, "1 ", cur, " = ", rate, " EUR"), /*#__PURE__*/React.createElement("div", {
    style: {
      height: '0.5px',
      background: 'var(--border-subtle)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, "Voc\xEA envia"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 16,
      color: 'var(--text-secondary)',
      marginTop: 2
    }
  }, cur, " ", amount)), /*#__PURE__*/React.createElement(PvIcon, {
    name: "arrowUpRight",
    size: 18,
    color: "var(--text-muted)"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)'
    }
  }, "Equivale a"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 18,
      fontWeight: 500,
      color: 'var(--red-500)',
      marginTop: 2
    }
  }, "\u20AC ", eur)))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)',
      display: 'flex',
      gap: 7,
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement(PvIcon, {
    name: "refresh",
    size: 14,
    color: "var(--text-muted)"
  }), "Fonte: European Central Bank \xB7 atualizado h\xE1 2 min")), step === 3 && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 500,
      color: 'var(--text-primary)'
    }
  }, "Revis\xE3o"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-tertiary)',
      marginTop: 3
    }
  }, "Confirme antes de enviar.")), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      border: '0.5px solid var(--border-subtle)',
      borderRadius: 16,
      padding: 18,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12.5,
      color: 'var(--text-muted)'
    }
  }, "Equivalente em EUR"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 42,
      fontWeight: 500,
      letterSpacing: '-0.02em',
      color: 'var(--text-primary)',
      marginTop: 6
    }
  }, "\u20AC ", eur), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-tertiary)',
      marginTop: 4
    }
  }, cur, " ", amount, " \xB7 taxa ", rate)), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      border: '0.5px solid var(--border-subtle)',
      borderRadius: 16,
      overflow: 'hidden'
    }
  }, [['Descrição', desc], ['Moeda', cur], ['Valor local', `${cur} ${amount}`], ['Fonte da taxa', 'ECB · ao vivo']].map(([k, v], i, a) => /*#__PURE__*/React.createElement("div", {
    key: k,
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      gap: 12,
      padding: '13px 16px',
      borderBottom: i < a.length - 1 ? '0.5px solid var(--border-subtle)' : 'none'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13.5,
      color: 'var(--text-tertiary)'
    }
  }, k), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13.5,
      color: 'var(--text-primary)',
      fontWeight: 500,
      textAlign: 'right'
    }
  }, v)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'sticky',
      bottom: 0,
      background: 'var(--bg-base)',
      borderTop: '0.5px solid var(--border-subtle)',
      padding: '14px 18px 22px',
      display: 'flex',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(PvBtnN, {
    variant: "ghost",
    size: "lg",
    onClick: step === 1 ? onCancel : () => setStep(step - 1)
  }, step === 1 ? 'Cancelar' : 'Voltar'), /*#__PURE__*/React.createElement(PvBtnN, {
    variant: "primary",
    size: "lg",
    fullWidth: true,
    iconRight: step === 3 ? /*#__PURE__*/React.createElement(PvIcon, {
      name: "send",
      size: 17,
      color: "#fff"
    }) : /*#__PURE__*/React.createElement(PvIcon, {
      name: "chevronRight",
      size: 18,
      color: "#fff"
    }),
    onClick: () => step === 3 ? onSubmit() : setStep(step + 1)
  }, step === 3 ? 'Enviar para aprovação' : 'Continuar')));
}
window.NewRequestMobile = NewRequestMobile;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/payravel-mobile/NewRequestMobile.jsx", error: String((e && e.message) || e) }); }

// ui_kits/payravel-mobile/mobileShell.jsx
try { (() => {
/* Payravel Mobile — shared shell: Icon (Lucide paths), StatusBar, PhoneFrame, BottomNav.
   Icons use Lucide path data (the system's recommended set) — stroke 1.8, round joins. */

const LUCIDE = {
  home: ['m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z', 'M9 22V12h6v10'],
  receipt: ['M4 2v20l2-1 2 1 2-1 2 1 2-1 2 1 2-1 2 1V2l-2 1-2-1-2 1-2-1-2 1-2-1-2 1Z', 'M16 8H8', 'M16 12H8', 'M11 16H8'],
  clock: ['M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20z', 'M12 6v6l4 2'],
  user: ['M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2', 'M12 3a4 4 0 1 0 0 8 4 4 0 0 0 0-8z'],
  plus: ['M5 12h14', 'M12 5v14'],
  chevronLeft: ['m15 18-6-6 6-6'],
  chevronRight: ['m9 18 6-6-6-6'],
  chevronDown: ['m6 9 6 6 6-6'],
  check: ['M20 6 9 17l-5-5'],
  x: ['M18 6 6 18', 'm6 6 12 12'],
  bell: ['M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9', 'M10.3 21a1.94 1.94 0 0 0 3.4 0'],
  arrowUpRight: ['M7 7h10v10', 'M7 17 17 7'],
  shield: ['M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z', 'm9 12 2 2 4-4'],
  search: ['M11 3a8 8 0 1 0 0 16 8 8 0 0 0 0-16z', 'm21 21-4.3-4.3'],
  calendar: ['M8 2v4', 'M16 2v4', 'M3 6a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z', 'M3 10h18'],
  refresh: ['M21 12a9 9 0 0 0-9-9 9.75 9.75 0 0 0-6.74 2.74L3 8', 'M3 3v5h5', 'M3 12a9 9 0 0 0 9 9 9.75 9.75 0 0 0 6.74-2.74L21 16', 'M21 21v-5h-5'],
  zap: ['M4 14a1 1 0 0 1-.78-1.63l9.9-10.2a.5.5 0 0 1 .86.46l-1.92 6.02A1 1 0 0 0 13 10h7a1 1 0 0 1 .78 1.63l-9.9 10.2a.5.5 0 0 1-.86-.46l1.92-6.02A1 1 0 0 0 11 14z'],
  send: ['M14.5 2.5 9 14l-3.5 3.5L2 22l4.5-1.5L18 9z', 'm22 2-7 20-4-9-9-4z'],
  alert: ['M12 9v4', 'M12 17h.01', 'M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z'],
  logout: ['M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4', 'M16 17l5-5-5-5', 'M21 12H9'],
  filter: ['M22 3H2l8 9.46V19l4 2v-8.54z']
};
function Icon({
  name,
  size = 22,
  color = 'currentColor',
  strokeWidth = 1.8,
  fill = 'none',
  style = {}
}) {
  const paths = LUCIDE[name] || [];
  return /*#__PURE__*/React.createElement("svg", {
    width: size,
    height: size,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: color,
    strokeWidth: strokeWidth,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      display: 'block',
      flex: 'none',
      ...style
    }
  }, paths.map((d, i) => /*#__PURE__*/React.createElement("path", {
    key: i,
    d: d,
    fill: fill === 'currentColor' ? color : fill
  })));
}
function StatusBar({
  dark = false
}) {
  const fg = dark ? '#fff' : 'var(--text-primary)';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      height: 44,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '0 22px 0 26px',
      flex: 'none',
      color: fg,
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15,
      fontWeight: 600,
      letterSpacing: '0.02em'
    }
  }, "9:41"), /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "12",
    viewBox: "0 0 18 12",
    fill: fg
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0",
    y: "8",
    width: "3",
    height: "4",
    rx: "1"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "5",
    y: "5",
    width: "3",
    height: "7",
    rx: "1"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "10",
    y: "2.5",
    width: "3",
    height: "9.5",
    rx: "1"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "15",
    y: "0",
    width: "3",
    height: "12",
    rx: "1"
  })), /*#__PURE__*/React.createElement("svg", {
    width: "17",
    height: "12",
    viewBox: "0 0 17 12",
    fill: "none",
    stroke: fg,
    strokeWidth: "1.6",
    strokeLinecap: "round"
  }, /*#__PURE__*/React.createElement("path", {
    d: "M1.5 4.2a11 11 0 0 1 14 0"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M4.2 7a7 7 0 0 1 8.6 0"
  }), /*#__PURE__*/React.createElement("path", {
    d: "M6.9 9.6a3 3 0 0 1 3.2 0"
  })), /*#__PURE__*/React.createElement("svg", {
    width: "26",
    height: "13",
    viewBox: "0 0 26 13",
    fill: "none"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "0.5",
    y: "0.5",
    width: "22",
    height: "12",
    rx: "3",
    stroke: fg,
    strokeOpacity: "0.4"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "2",
    y: "2",
    width: "17",
    height: "9",
    rx: "1.5",
    fill: fg
  }), /*#__PURE__*/React.createElement("rect", {
    x: "24",
    y: "4",
    width: "1.6",
    height: "5",
    rx: "0.8",
    fill: fg,
    fillOpacity: "0.4"
  }))));
}
const TABS = [{
  id: 'home',
  label: 'Início',
  icon: 'home'
}, {
  id: 'requests',
  label: 'Requisições',
  icon: 'receipt'
}, {
  id: 'fab',
  label: '',
  icon: 'plus'
}, {
  id: 'finance',
  label: 'Financeiro',
  icon: 'shield'
}, {
  id: 'profile',
  label: 'Perfil',
  icon: 'user'
}];
function BottomNav({
  active = 'home',
  onTab = () => {},
  onFab = () => {}
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 'none',
      position: 'relative',
      background: 'rgba(20,20,20,0.92)',
      backdropFilter: 'blur(12px)',
      borderTop: '0.5px solid var(--border-subtle)',
      padding: '8px 12px 26px',
      display: 'flex',
      alignItems: 'flex-start',
      justifyContent: 'space-between'
    }
  }, TABS.map(t => {
    if (t.id === 'fab') {
      return /*#__PURE__*/React.createElement("button", {
        key: "fab",
        onClick: onFab,
        style: {
          width: 52,
          height: 52,
          marginTop: -22,
          borderRadius: 18,
          background: 'var(--red-500)',
          border: 'none',
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: '0 6px 18px rgba(204,0,0,0.45)',
          flex: 'none'
        }
      }, /*#__PURE__*/React.createElement(Icon, {
        name: "plus",
        size: 26,
        color: "#fff",
        strokeWidth: 2.4
      }));
    }
    const on = active === t.id;
    return /*#__PURE__*/React.createElement("button", {
      key: t.id,
      onClick: () => onTab(t.id),
      style: {
        background: 'none',
        border: 'none',
        cursor: 'pointer',
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        gap: 4,
        width: 60,
        padding: 0
      }
    }, /*#__PURE__*/React.createElement(Icon, {
      name: t.icon,
      size: 22,
      color: on ? 'var(--red-500)' : 'var(--text-muted)',
      strokeWidth: on ? 2.2 : 1.8
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 10.5,
        fontWeight: 500,
        color: on ? 'var(--text-primary)' : 'var(--text-muted)',
        fontFamily: 'var(--font-sans)'
      }
    }, t.label));
  }));
}

/* PhoneFrame — a bezel-less 390-wide screen, centered on the canvas. */
function PhoneFrame({
  children,
  dark = false,
  showNav = true,
  activeTab = 'home',
  onTab,
  onFab,
  scrollKey
}) {
  const scrollRef = React.useRef(null);
  React.useEffect(() => {
    if (scrollRef.current) scrollRef.current.scrollTop = 0;
  }, [scrollKey]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 390,
      height: 844,
      flex: 'none',
      background: 'var(--bg-base)',
      borderRadius: 44,
      border: '0.5px solid var(--border-default)',
      overflow: 'hidden',
      position: 'relative',
      display: 'flex',
      flexDirection: 'column',
      boxShadow: '0 24px 70px rgba(0,0,0,0.6)'
    }
  }, /*#__PURE__*/React.createElement(StatusBar, {
    dark: dark
  }), /*#__PURE__*/React.createElement("div", {
    ref: scrollRef,
    style: {
      flex: 1,
      overflowY: 'auto',
      overflowX: 'hidden',
      position: 'relative'
    }
  }, children), showNav && /*#__PURE__*/React.createElement(BottomNav, {
    active: activeTab,
    onTab: onTab,
    onFab: onFab
  }));
}
Object.assign(window, {
  PvIcon: Icon,
  PvStatusBar: StatusBar,
  PvBottomNav: BottomNav,
  PvPhoneFrame: PhoneFrame
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/payravel-mobile/mobileShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/payravel-mobile/parts.jsx
try { (() => {
/* Payravel Mobile — shared content bits: status colors, RequestCard. */
const STATUS_M = {
  pending: {
    fg: 'var(--status-pending-fg)',
    bg: 'var(--status-pending-bg)',
    bd: 'var(--status-pending-border)',
    label: 'Pendente'
  },
  approved: {
    fg: 'var(--status-approved-fg)',
    bg: 'var(--status-approved-bg)',
    bd: 'var(--status-approved-border)',
    label: 'Aprovado'
  },
  rejected: {
    fg: 'var(--status-rejected-fg)',
    bg: 'var(--status-rejected-bg)',
    bd: 'var(--status-rejected-border)',
    label: 'Rejeitado'
  },
  expired: {
    fg: 'var(--status-expired-fg)',
    bg: 'var(--status-expired-bg)',
    bd: 'var(--status-expired-border)',
    label: 'Expirado'
  }
};
function StatusChip({
  status
}) {
  const s = STATUS_M[status] || STATUS_M.pending;
  return /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 5,
      padding: '3px 9px',
      borderRadius: 999,
      fontSize: 11.5,
      fontWeight: 500,
      color: s.fg,
      background: s.bg,
      border: `0.5px solid ${s.bd}`,
      fontFamily: 'var(--font-sans)',
      whiteSpace: 'nowrap'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 5,
      height: 5,
      borderRadius: 999,
      background: s.fg
    }
  }), s.label);
}

/* RequestCard — stacked, app-style. Flag tile + desc + amounts + status. */
function RequestCard({
  req,
  onClick,
  showEmployee = false
}) {
  return /*#__PURE__*/React.createElement("button", {
    onClick: onClick,
    style: {
      width: '100%',
      textAlign: 'left',
      cursor: 'pointer',
      background: 'var(--surface-card)',
      border: '0.5px solid var(--border-subtle)',
      borderRadius: 16,
      padding: 16,
      display: 'flex',
      flexDirection: 'column',
      gap: 12,
      fontFamily: 'var(--font-sans)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 40,
      height: 40,
      borderRadius: 12,
      flex: 'none',
      background: 'var(--bg-input)',
      border: '0.5px solid var(--border-default)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 20
    }
  }, req.flag), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14.5,
      fontWeight: 500,
      color: 'var(--text-primary)',
      overflow: 'hidden',
      textOverflow: 'ellipsis',
      whiteSpace: 'nowrap'
    }
  }, req.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)',
      marginTop: 2
    }
  }, showEmployee ? req.employee : req.id, " \xB7 ", req.date || req.expires)), req.status ? /*#__PURE__*/React.createElement(StatusChip, {
    status: req.status
  }) : null), /*#__PURE__*/React.createElement("div", {
    style: {
      height: '0.5px',
      background: 'var(--border-subtle)'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11.5,
      color: 'var(--text-muted)'
    }
  }, req.cur, " \xB7 valor local"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 15,
      color: 'var(--text-secondary)',
      fontVariantNumeric: 'tabular-nums',
      marginTop: 2
    }
  }, req.local)), /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'right'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11.5,
      color: 'var(--text-muted)'
    }
  }, "em EUR"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 17,
      fontWeight: 500,
      color: 'var(--text-primary)',
      fontVariantNumeric: 'tabular-nums',
      marginTop: 2
    }
  }, "\u20AC ", req.eur))));
}
Object.assign(window, {
  PvStatusChip: StatusChip,
  PvRequestCard: RequestCard,
  PV_STATUS_M: STATUS_M
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/payravel-mobile/parts.jsx", error: String((e && e.message) || e) }); }

// ui_kits/payravel/DashboardScreen.jsx
try { (() => {
/* Payravel — Dashboard do funcionário. Topbar + KPI cards + requests table. */
const {
  Topbar: DashTopbar,
  MetricCard: DashMetric,
  Badge: DashBadge,
  Button: DashButton
} = window.PayravelDesignSystem_6c6388;
function Th({
  children,
  align = 'left',
  w
}) {
  return /*#__PURE__*/React.createElement("th", {
    style: {
      textAlign: align,
      padding: '0 16px 10px',
      fontSize: 11,
      letterSpacing: '0.04em',
      textTransform: 'uppercase',
      color: 'var(--text-muted)',
      fontWeight: 500,
      whiteSpace: 'nowrap',
      width: w
    }
  }, children);
}
function Td({
  children,
  align = 'left',
  mono = false,
  color = 'var(--text-secondary)'
}) {
  return /*#__PURE__*/React.createElement("td", {
    style: {
      padding: '14px 16px',
      fontSize: 14,
      textAlign: align,
      color,
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
      fontVariantNumeric: mono ? 'tabular-nums' : 'normal',
      whiteSpace: 'nowrap'
    }
  }, children);
}
function DashboardScreen({
  onNewRequest = () => {},
  onOpenRequest = () => {}
}) {
  const {
    requests
  } = window.PAYRAVEL_DATA;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: 600,
      background: 'var(--bg-base)'
    }
  }, /*#__PURE__*/React.createElement(DashTopbar, {
    user: {
      name: 'Marina Alves'
    },
    nav: [{
      label: 'Dashboard',
      active: true
    }, {
      label: 'Requisições'
    }, {
      label: 'Histórico'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      maxWidth: 1180,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'flex-end',
      justifyContent: 'space-between',
      marginBottom: 24
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 22,
      fontWeight: 500,
      color: 'var(--text-primary)',
      margin: 0
    }
  }, "Ol\xE1, Marina"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: 'var(--text-tertiary)',
      marginTop: 4
    }
  }, "Suas requisi\xE7\xF5es de pagamento deste m\xEAs.")), /*#__PURE__*/React.createElement(DashButton, {
    variant: "primary",
    onClick: onNewRequest,
    iconLeft: /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 16,
        lineHeight: 0
      }
    }, "+")
  }, "Nova requisi\xE7\xE3o")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 14,
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement(DashMetric, {
    label: "Total enviado",
    value: "\u20AC 3.408",
    sub: "5 requisi\xE7\xF5es",
    accent: true
  }), /*#__PURE__*/React.createElement(DashMetric, {
    label: "Pendente",
    value: "1",
    tone: "pending",
    sub: "\u20AC 1.104 em revis\xE3o"
  }), /*#__PURE__*/React.createElement(DashMetric, {
    label: "Aprovado",
    value: "2",
    tone: "approved",
    sub: "\u20AC 1.792 liberados"
  }), /*#__PURE__*/React.createElement(DashMetric, {
    label: "Rejeitado",
    value: "1",
    tone: "rejected",
    sub: "\u20AC 318 recusados"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      border: '0.5px solid var(--border-subtle)',
      borderRadius: 8,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 20px',
      borderBottom: '0.5px solid var(--border-subtle)',
      fontSize: 14,
      fontWeight: 500,
      color: 'var(--text-primary)'
    }
  }, "Requisi\xE7\xF5es recentes"), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      borderBottom: '0.5px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(Th, null, "Descri\xE7\xE3o"), /*#__PURE__*/React.createElement(Th, {
    align: "right"
  }, "Valor local"), /*#__PURE__*/React.createElement(Th, null, "Moeda"), /*#__PURE__*/React.createElement(Th, {
    align: "right"
  }, "Em EUR"), /*#__PURE__*/React.createElement(Th, null, "Data"), /*#__PURE__*/React.createElement(Th, null, "Status"))), /*#__PURE__*/React.createElement("tbody", null, requests.map((r, i) => /*#__PURE__*/React.createElement("tr", {
    key: r.id,
    onClick: () => onOpenRequest(r),
    style: {
      borderBottom: i < requests.length - 1 ? '0.5px solid var(--border-subtle)' : 'none',
      cursor: 'pointer',
      transition: 'background 120ms ease'
    },
    onMouseEnter: e => e.currentTarget.style.background = 'var(--bg-row-hover)',
    onMouseLeave: e => e.currentTarget.style.background = 'transparent'
  }, /*#__PURE__*/React.createElement(Td, {
    color: "var(--text-primary)"
  }, r.desc), /*#__PURE__*/React.createElement(Td, {
    align: "right",
    mono: true
  }, r.local), /*#__PURE__*/React.createElement(Td, null, /*#__PURE__*/React.createElement("span", {
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 15
    }
  }, r.flag), r.cur)), /*#__PURE__*/React.createElement(Td, {
    align: "right",
    mono: true,
    color: "var(--text-primary)"
  }, "\u20AC ", r.eur), /*#__PURE__*/React.createElement(Td, null, r.date), /*#__PURE__*/React.createElement(Td, null, /*#__PURE__*/React.createElement(DashBadge, {
    status: r.status
  })))))))));
}
window.DashboardScreen = DashboardScreen;
window.PvTh = Th;
window.PvTd = Td;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/payravel/DashboardScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/payravel/FinancePanelScreen.jsx
try { (() => {
/* Payravel — Painel financeiro (role: finance). Fila de aprovação com ações inline. */
const FP = window.PayravelDesignSystem_6c6388;
const {
  Topbar: FpTopbar,
  MetricCard: FpMetric,
  Badge: FpBadge
} = FP;
function ActionBtn({
  kind,
  onClick
}) {
  const isApprove = kind === 'approve';
  const [hover, setHover] = React.useState(false);
  const fg = isApprove ? 'var(--status-approved-fg)' : 'var(--status-rejected-fg)';
  const bg = isApprove ? 'var(--status-approved-bg)' : 'var(--status-rejected-bg)';
  const bd = isApprove ? 'var(--status-approved-border)' : 'var(--status-rejected-border)';
  return /*#__PURE__*/React.createElement("button", {
    type: "button",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    title: isApprove ? 'Aprovar' : 'Rejeitar',
    style: {
      width: 30,
      height: 30,
      borderRadius: 6,
      cursor: 'pointer',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontSize: 14,
      color: fg,
      background: hover ? bg : 'transparent',
      border: `0.5px solid ${hover ? bd : 'var(--border-default)'}`,
      transition: 'all 120ms ease',
      fontFamily: 'var(--font-sans)'
    }
  }, isApprove ? '✓' : '✕');
}
function FinancePanelScreen() {
  const [queue, setQueue] = React.useState(window.PAYRAVEL_DATA.financeQueue);
  const [resolved, setResolved] = React.useState({}); // id -> 'approved' | 'rejected'

  function resolve(id, status) {
    setResolved(r => ({
      ...r,
      [id]: status
    }));
    setTimeout(() => setQueue(q => q.filter(x => x.id !== id)), 900);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: 600,
      background: 'var(--bg-base)'
    }
  }, /*#__PURE__*/React.createElement(FpTopbar, {
    user: {
      name: 'Lucas Costa',
      role: 'Finance'
    },
    nav: [{
      label: 'Fila de aprovação',
      active: true
    }, {
      label: 'Histórico'
    }, {
      label: 'Relatórios'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      maxWidth: 1180,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 22,
      fontWeight: 500,
      color: 'var(--text-primary)',
      margin: '0 0 4px'
    }
  }, "Painel financeiro"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: 'var(--text-tertiary)',
      margin: '0 0 24px'
    }
  }, "Revise e libere as requisi\xE7\xF5es da equipe."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4, 1fr)',
      gap: 14,
      marginBottom: 28
    }
  }, /*#__PURE__*/React.createElement(FpMetric, {
    label: "Aguardando revis\xE3o",
    value: String(queue.length),
    accent: true,
    sub: "na sua fila"
  }), /*#__PURE__*/React.createElement(FpMetric, {
    label: "Total em EUR",
    value: "\u20AC 2.798",
    sub: "valor pendente"
  }), /*#__PURE__*/React.createElement(FpMetric, {
    label: "Aprovados hoje",
    value: "7",
    tone: "approved",
    sub: "\u20AC 5.120 liberados"
  }), /*#__PURE__*/React.createElement(FpMetric, {
    label: "Expiram em 24h",
    value: "2",
    tone: "pending",
    sub: "a\xE7\xE3o necess\xE1ria"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-card)',
      border: '0.5px solid var(--border-subtle)',
      borderRadius: 8,
      overflow: 'hidden'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 20px',
      borderBottom: '0.5px solid var(--border-subtle)',
      fontSize: 14,
      fontWeight: 500,
      color: 'var(--text-primary)'
    }
  }, "Fila de aprova\xE7\xE3o"), /*#__PURE__*/React.createElement("table", {
    style: {
      width: '100%',
      borderCollapse: 'collapse'
    }
  }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", {
    style: {
      borderBottom: '0.5px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement(window.PvTh, null, "Funcion\xE1rio / Descri\xE7\xE3o"), /*#__PURE__*/React.createElement(window.PvTh, {
    align: "right"
  }, "Valor local"), /*#__PURE__*/React.createElement(window.PvTh, null, "Moeda"), /*#__PURE__*/React.createElement(window.PvTh, {
    align: "right"
  }, "Em EUR"), /*#__PURE__*/React.createElement(window.PvTh, null, "Expira"), /*#__PURE__*/React.createElement(window.PvTh, {
    align: "right"
  }, "A\xE7\xE3o"))), /*#__PURE__*/React.createElement("tbody", null, queue.map((r, i) => {
    const res = resolved[r.id];
    const critical = r.critical && !res;
    return /*#__PURE__*/React.createElement("tr", {
      key: r.id,
      style: {
        borderBottom: i < queue.length - 1 ? '0.5px solid var(--border-subtle)' : 'none',
        background: res ? res === 'approved' ? 'var(--status-approved-bg)' : 'var(--status-rejected-bg)' : critical ? 'var(--status-pending-bg)' : 'transparent',
        transition: 'background 200ms ease'
      }
    }, /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '14px 16px'
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14,
        color: 'var(--text-primary)'
      }
    }, r.desc), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 12,
        color: 'var(--text-muted)',
        marginTop: 2
      }
    }, r.employee, " \xB7 ", r.id)), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '14px 16px',
        textAlign: 'right',
        fontFamily: 'var(--font-mono)',
        fontVariantNumeric: 'tabular-nums',
        fontSize: 14,
        color: 'var(--text-secondary)'
      }
    }, r.local), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '14px 16px',
        fontSize: 14,
        color: 'var(--text-secondary)'
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 15
      }
    }, r.flag), r.cur)), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '14px 16px',
        textAlign: 'right',
        fontFamily: 'var(--font-mono)',
        fontVariantNumeric: 'tabular-nums',
        fontSize: 14,
        color: 'var(--text-primary)'
      }
    }, "\u20AC ", r.eur), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '14px 16px',
        fontSize: 13,
        color: critical ? 'var(--status-pending-fg)' : 'var(--text-tertiary)',
        fontFamily: 'var(--font-mono)'
      }
    }, critical && /*#__PURE__*/React.createElement("span", {
      style: {
        marginRight: 5
      }
    }, "\u23F1"), r.expires), /*#__PURE__*/React.createElement("td", {
      style: {
        padding: '14px 16px',
        textAlign: 'right'
      }
    }, res ? /*#__PURE__*/React.createElement(FpBadge, {
      status: res
    }) : /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'inline-flex',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(ActionBtn, {
      kind: "approve",
      onClick: () => resolve(r.id, 'approved')
    }), /*#__PURE__*/React.createElement(ActionBtn, {
      kind: "reject",
      onClick: () => resolve(r.id, 'rejected')
    }))));
  }), queue.length === 0 && /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("td", {
    colSpan: 6,
    style: {
      padding: '40px 16px',
      textAlign: 'center',
      color: 'var(--text-muted)',
      fontSize: 14
    }
  }, "Fila vazia \u2014 tudo revisado. \u2713")))))));
}
window.FinancePanelScreen = FinancePanelScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/payravel/FinancePanelScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/payravel/LoginScreen.jsx
try { (() => {
/* Payravel — Login / Registro. Split layout: red brand panel + dark form. */
const PvNS = window.PayravelDesignSystem_6c6388 || {};
const {
  Button: PvButton,
  Input: PvInput
} = PvNS;
const PvLogo = PvNS.Logo || function FallbackLogo({
  wordmarkColor = '#fff'
}) {
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 22,
      fontWeight: 500,
      letterSpacing: '-0.01em',
      color: wordmarkColor
    }
  }, "Payravel");
};
function LoginScreen({
  onLogin = () => {}
}) {
  const [mode, setMode] = React.useState('login'); // 'login' | 'register'
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      height: '100%',
      minHeight: 600,
      background: 'var(--bg-base)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: '0 0 42%',
      background: 'var(--red-500)',
      color: '#fff',
      padding: '56px 48px',
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'space-between'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(PvLogo, {
    size: 54,
    color: "#fff",
    knockout: "#CC0000",
    wordmarkColor: "#fff"
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 40,
      fontWeight: 500,
      lineHeight: 1.12,
      letterSpacing: '-0.02em',
      margin: 0
    }
  }, "Pagamentos", /*#__PURE__*/React.createElement("br", null), "multi-moeda,", /*#__PURE__*/React.createElement("br", null), "sem fronteiras."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 16,
      lineHeight: 1.5,
      color: 'rgba(255,255,255,0.82)',
      marginTop: 20,
      maxWidth: 360
    }
  }, "Solicite, converta e aprove reembolsos da sua equipe global \u2014 c\xE2mbio ao vivo, tudo em EUR.")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'rgba(255,255,255,0.7)'
    }
  }, "\xA9 2026 Payravel \xB7 Buzzvel")), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: '100%',
      maxWidth: 360,
      display: 'flex',
      flexDirection: 'column',
      gap: 22
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h2", {
    style: {
      fontSize: 22,
      fontWeight: 500,
      color: 'var(--text-primary)',
      margin: 0
    }
  }, mode === 'login' ? 'Entrar na conta' : 'Criar conta'), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 14,
      color: 'var(--text-tertiary)',
      marginTop: 6
    }
  }, mode === 'login' ? 'Acesse seu painel de requisições.' : 'Comece a solicitar pagamentos hoje.')), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 14
    }
  }, mode === 'register' && /*#__PURE__*/React.createElement(PvInput, {
    label: "Nome completo",
    placeholder: "Marina Alves",
    defaultValue: ""
  }), /*#__PURE__*/React.createElement(PvInput, {
    label: "E-mail",
    type: "email",
    placeholder: "voce@empresa.com",
    defaultValue: "marina@empresa.com"
  }), /*#__PURE__*/React.createElement(PvInput, {
    label: "Senha",
    type: "password",
    placeholder: "\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022",
    defaultValue: "123456"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(PvButton, {
    variant: "primary",
    fullWidth: true,
    onClick: onLogin
  }, mode === 'login' ? 'Entrar' : 'Registrar'), /*#__PURE__*/React.createElement(PvButton, {
    variant: "ghost",
    onClick: () => setMode(mode === 'login' ? 'register' : 'login')
  }, mode === 'login' ? 'Registrar' : 'Entrar')), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      textAlign: 'center'
    }
  }, mode === 'login' ? 'Esqueceu a senha? ' : 'Já tem conta? ', /*#__PURE__*/React.createElement("span", {
    onClick: () => setMode(mode === 'login' ? 'register' : 'login'),
    style: {
      color: 'var(--text-secondary)',
      cursor: 'pointer',
      borderBottom: '0.5px solid var(--border-strong)'
    }
  }, mode === 'login' ? 'Recuperar acesso' : 'Entrar')))));
}
window.LoginScreen = LoginScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/payravel/LoginScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/payravel/NewRequestScreen.jsx
try { (() => {
/* Payravel — Nova requisição de pagamento. Stepper lateral + form com câmbio ao vivo. */
const NR = window.PayravelDesignSystem_6c6388;
const {
  Topbar: NrTopbar,
  Stepper: NrStepper,
  Input: NrInput,
  Select: NrSelect,
  Button: NrButton,
  Badge: NrBadge,
  Card: NrCard
} = NR;
function parseLocal(str) {
  if (!str) return 0;
  const n = String(str).replace(/\./g, '').replace(',', '.').replace(/[^0-9.]/g, '');
  return parseFloat(n) || 0;
}
function fmtEUR(n) {
  return n.toLocaleString('pt-BR', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  });
}
function NewRequestScreen({
  onCancel = () => {},
  onSubmit = () => {}
}) {
  const {
    currencies
  } = window.PAYRAVEL_DATA;
  const [desc, setDesc] = React.useState('Licença anual Figma');
  const [amount, setAmount] = React.useState('1.200,00');
  const [cur, setCur] = React.useState('USD');
  const selected = currencies.find(c => c.value === cur);
  const rate = parseLocal(selected.rate);
  const eur = parseLocal(amount) * rate;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: 600,
      background: 'var(--bg-base)'
    }
  }, /*#__PURE__*/React.createElement(NrTopbar, {
    user: {
      name: 'Marina Alves'
    },
    nav: [{
      label: 'Dashboard'
    }, {
      label: 'Requisições',
      active: true
    }, {
      label: 'Histórico'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      maxWidth: 1000,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: 22,
      fontWeight: 500,
      color: 'var(--text-primary)',
      margin: '0 0 24px'
    }
  }, "Nova requisi\xE7\xE3o de pagamento"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '220px 1fr',
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: 8
    }
  }, /*#__PURE__*/React.createElement(NrStepper, {
    current: 1,
    steps: [{
      title: 'Detalhes',
      desc: 'Descrição e valor'
    }, {
      title: 'Câmbio',
      desc: 'Taxa ao vivo'
    }, {
      title: 'Revisão',
      desc: 'Confirmar e enviar'
    }]
  })), /*#__PURE__*/React.createElement(NrCard, {
    style: {
      padding: 28
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(NrInput, {
    label: "Descri\xE7\xE3o",
    value: desc,
    onChange: e => setDesc(e.target.value),
    placeholder: "Ex. Licen\xE7a de software"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(NrInput, {
    label: "Valor",
    value: amount,
    onChange: e => setAmount(e.target.value),
    mono: true,
    placeholder: "0,00"
  }), /*#__PURE__*/React.createElement(NrSelect, {
    label: "Moeda",
    value: cur,
    onChange: setCur,
    options: currencies
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      height: '0.5px',
      background: 'var(--border-subtle)',
      margin: '4px 0'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 14
    }
  }, /*#__PURE__*/React.createElement(NrInput, {
    label: "Taxa de c\xE2mbio",
    value: selected.rate,
    readOnly: true,
    mono: true,
    suffix: /*#__PURE__*/React.createElement(NrBadge, {
      status: "approved"
    }, "ao vivo \u2713")
  }), /*#__PURE__*/React.createElement(NrInput, {
    label: "Equivalente em EUR",
    value: `€ ${fmtEUR(eur)}`,
    readOnly: true,
    mono: true,
    hint: "Calculado automaticamente"
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      gap: 10,
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(NrButton, {
    variant: "ghost",
    onClick: onCancel
  }, "Cancelar"), /*#__PURE__*/React.createElement(NrButton, {
    variant: "primary",
    onClick: onSubmit
  }, "Enviar para aprova\xE7\xE3o")))))));
}
window.NewRequestScreen = NewRequestScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/payravel/NewRequestScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/payravel/RequestDetailScreen.jsx
try { (() => {
/* Payravel — Detalhe da requisição. Coluna principal (valor + info) + timeline. */
const RD = window.PayravelDesignSystem_6c6388;
const {
  Topbar: RdTopbar,
  Badge: RdBadge,
  Button: RdButton,
  Card: RdCard
} = RD;
function InfoRow({
  label,
  value,
  mono = true,
  last = false
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      padding: '13px 0',
      borderBottom: last ? 'none' : '0.5px solid var(--border-subtle)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 13,
      color: 'var(--text-tertiary)'
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 14,
      color: 'var(--text-primary)',
      fontFamily: mono ? 'var(--font-mono)' : 'var(--font-sans)',
      fontVariantNumeric: mono ? 'tabular-nums' : 'normal'
    }
  }, value));
}
function TimelineItem({
  title,
  time,
  state,
  last
}) {
  const colors = {
    done: 'var(--status-approved-fg)',
    current: 'var(--status-pending-fg)',
    future: 'var(--text-muted)'
  };
  const c = colors[state];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 12,
      height: 12,
      borderRadius: 999,
      flex: 'none',
      marginTop: 3,
      background: state === 'future' ? 'transparent' : c,
      border: `1.5px solid ${c}`
    }
  }), !last && /*#__PURE__*/React.createElement("span", {
    style: {
      width: '0.5px',
      flex: 1,
      minHeight: 32,
      background: 'var(--border-default)'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      paddingBottom: last ? 0 : 18
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: state === 'future' ? 'var(--text-tertiary)' : 'var(--text-primary)'
    }
  }, title), time && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)',
      marginTop: 2,
      fontFamily: 'var(--font-mono)'
    }
  }, time)));
}
function RequestDetailScreen({
  request,
  onBack = () => {}
}) {
  const r = request || window.PAYRAVEL_DATA.requests[0];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      minHeight: 600,
      background: 'var(--bg-base)'
    }
  }, /*#__PURE__*/React.createElement(RdTopbar, {
    user: {
      name: 'Marina Alves'
    },
    nav: [{
      label: 'Dashboard'
    }, {
      label: 'Requisições',
      active: true
    }, {
      label: 'Histórico'
    }]
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 32,
      maxWidth: 1000,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: onBack,
    style: {
      background: 'none',
      border: 'none',
      color: 'var(--text-tertiary)',
      fontSize: 13,
      cursor: 'pointer',
      padding: 0,
      marginBottom: 18,
      fontFamily: 'var(--font-sans)'
    }
  }, "\u2190 Voltar para requisi\xE7\xF5es"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 320px',
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 20
    }
  }, /*#__PURE__*/React.createElement(RdCard, {
    style: {
      padding: 28
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'flex-start'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)',
      marginBottom: 8
    }
  }, r.id, " \xB7 ", r.desc), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 52,
      fontWeight: 500,
      fontFamily: 'var(--font-mono)',
      letterSpacing: '-0.02em',
      color: 'var(--text-primary)',
      fontVariantNumeric: 'tabular-nums',
      lineHeight: 1
    }
  }, "\u20AC ", r.eur), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      color: 'var(--text-tertiary)',
      marginTop: 10,
      fontFamily: 'var(--font-mono)'
    }
  }, r.flag, " ", r.local, " ", r.cur, " \xB7 taxa ", r.rate)), /*#__PURE__*/React.createElement(RdBadge, {
    status: r.status
  }))), /*#__PURE__*/React.createElement(RdCard, {
    style: {
      padding: '8px 24px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 500,
      color: 'var(--text-tertiary)',
      padding: '16px 0 4px'
    }
  }, "Informa\xE7\xF5es da convers\xE3o"), /*#__PURE__*/React.createElement(InfoRow, {
    label: "Moeda original",
    value: `${r.flag} ${r.cur}`,
    mono: false
  }), /*#__PURE__*/React.createElement(InfoRow, {
    label: "Valor local",
    value: `${r.local} ${r.cur}`
  }), /*#__PURE__*/React.createElement(InfoRow, {
    label: "Equivalente em EUR",
    value: `€ ${r.eur}`
  }), /*#__PURE__*/React.createElement(InfoRow, {
    label: "Taxa aplicada",
    value: r.rate
  }), /*#__PURE__*/React.createElement(InfoRow, {
    label: "Fonte da taxa",
    value: "ECB \xB7 openexchangerates",
    mono: false
  }), /*#__PURE__*/React.createElement(InfoRow, {
    label: "Criada em",
    value: `${r.date} · 09:42`,
    last: true
  }))), /*#__PURE__*/React.createElement(RdCard, {
    style: {
      padding: 24,
      height: 'fit-content'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: 'var(--text-primary)',
      marginBottom: 20
    }
  }, "Hist\xF3rico"), /*#__PURE__*/React.createElement(TimelineItem, {
    title: "Requisi\xE7\xE3o criada",
    time: "08 jun \xB7 09:42",
    state: "done"
  }), /*#__PURE__*/React.createElement(TimelineItem, {
    title: "C\xE2mbio capturado (ao vivo)",
    time: "08 jun \xB7 09:42",
    state: "done"
  }), /*#__PURE__*/React.createElement(TimelineItem, {
    title: r.status === 'pending' ? 'Aguardando aprovação' : 'Em revisão pelo financeiro',
    time: r.status === 'pending' ? 'Agora' : '08 jun · 11:10',
    state: r.status === 'pending' ? 'current' : 'done'
  }), /*#__PURE__*/React.createElement(TimelineItem, {
    title: r.status === 'approved' ? 'Aprovado · pagamento liberado' : r.status === 'rejected' ? 'Rejeitado pelo financeiro' : r.status === 'expired' ? 'Expirou sem revisão' : 'Resultado da aprovação',
    time: r.status === 'pending' ? null : '08 jun · 14:25',
    state: r.status === 'pending' ? 'future' : 'done',
    last: true
  })))));
}
window.RequestDetailScreen = RequestDetailScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/payravel/RequestDetailScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/payravel/data.js
try { (() => {
/* Shared mock data for the Payravel UI kit. Sets window.PAYRAVEL_DATA. */
(function () {
  const requests = [{
    id: 'PR-1042',
    desc: 'Licença anual Figma',
    local: '1.200,00',
    cur: 'USD',
    flag: '🇺🇸',
    eur: '1.104,00',
    rate: '0,9200',
    date: '08 jun 2026',
    status: 'pending',
    employee: 'Marina Alves'
  }, {
    id: 'PR-1039',
    desc: 'Hospedagem AWS — maio',
    local: '3.480,00',
    cur: 'BRL',
    flag: '🇧🇷',
    eur: '646,28',
    rate: '0,1857',
    date: '06 jun 2026',
    status: 'approved',
    employee: 'João Pereira'
  }, {
    id: 'PR-1037',
    desc: 'Consultoria UX (12h)',
    local: '980,00',
    cur: 'GBP',
    flag: '🇬🇧',
    eur: '1.146,60',
    rate: '1,1700',
    date: '05 jun 2026',
    status: 'approved',
    employee: 'Marina Alves'
  }, {
    id: 'PR-1031',
    desc: 'Equipamento — monitor',
    local: '54.000',
    cur: 'JPY',
    flag: '🇯🇵',
    eur: '318,60',
    rate: '0,0059',
    date: '02 jun 2026',
    status: 'rejected',
    employee: 'Sofia Marques'
  }, {
    id: 'PR-1024',
    desc: 'Domínio + SSL (3 anos)',
    local: '210,00',
    cur: 'USD',
    flag: '🇺🇸',
    eur: '193,20',
    rate: '0,9200',
    date: '24 mai 2026',
    status: 'expired',
    employee: 'João Pereira'
  }];
  const financeQueue = [{
    id: 'PR-1042',
    desc: 'Licença anual Figma',
    employee: 'Marina Alves',
    local: '1.200,00',
    cur: 'USD',
    flag: '🇺🇸',
    eur: '1.104,00',
    expires: '4h',
    critical: true
  }, {
    id: 'PR-1041',
    desc: 'Campanha Meta Ads',
    employee: 'Sofia Marques',
    local: '2.500,00',
    cur: 'BRL',
    flag: '🇧🇷',
    eur: '464,25',
    expires: '19h',
    critical: true
  }, {
    id: 'PR-1040',
    desc: 'Plano Notion Team',
    employee: 'João Pereira',
    local: '480,00',
    cur: 'USD',
    flag: '🇺🇸',
    eur: '441,60',
    expires: '2d',
    critical: false
  }, {
    id: 'PR-1038',
    desc: 'Tradução jurídica',
    employee: 'Marina Alves',
    local: '640,00',
    cur: 'GBP',
    flag: '🇬🇧',
    eur: '748,80',
    expires: '3d',
    critical: false
  }];
  const currencies = [{
    value: 'USD',
    label: 'Dólar americano',
    flag: '🇺🇸',
    meta: 'USD',
    rate: '0,9200'
  }, {
    value: 'BRL',
    label: 'Real brasileiro',
    flag: '🇧🇷',
    meta: 'BRL',
    rate: '0,1857'
  }, {
    value: 'GBP',
    label: 'Libra esterlina',
    flag: '🇬🇧',
    meta: 'GBP',
    rate: '1,1700'
  }, {
    value: 'JPY',
    label: 'Iene japonês',
    flag: '🇯🇵',
    meta: 'JPY',
    rate: '0,0059'
  }];
  window.PAYRAVEL_DATA = {
    requests,
    financeQueue,
    currencies
  };
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/payravel/data.js", error: String((e && e.message) || e) }); }

__ds_ns.Logo = __ds_scope.Logo;

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.MetricCard = __ds_scope.MetricCard;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.Pill = __ds_scope.Pill;

__ds_ns.Stepper = __ds_scope.Stepper;

__ds_ns.Topbar = __ds_scope.Topbar;

})();
